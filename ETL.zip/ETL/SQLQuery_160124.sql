CREATE TABLE emp_data(
	SI_NO int PRIMARY KEY,
	NAME varchar(15),
	SALARY int,
	AGE int
);
INSERT INTO emp_data(SI_NO , NAME , SALARY ,AGE)
VALUES ('1', 'Harsh', 2000,19),
       ('2', 'Dhanraj', 300,20),
       ('3', 'Ashish', 1500,19),
       ('4', 'Harsh', 3500,19),
	   ('5', 'Ashish', 1500,19);

-- Update SALARY details of Dhanraj
UPDATE emp_data
SET SALARY = 3000
WHERE SI_NO = 2;

SELECT * FROM emp_data

--1. add column address with the length (30)
ALTER TABLE emp_data
ADD ADDRESS varchar(30);

--2. modify the length of the column address i.e. 30 to 50
ALTER TABLE emp_data
ALTER COLUMN ADDRESS varchar(50);

--3. change the name of the address column to address_1.
EXEC sp_rename 'emp_data.ADDRESS', 'ADDRESS_1', 'COLUMN';

--4. add not null constraint on the column that si no 
ALTER TABLE emp_data
ALTER COLUMN SI_NO INT NOT NULL;

--5. add a check constraint on the age column that the age can't be more than 100
ALTER TABLE emp_data
ADD CONSTRAINT CHECK_Age CHECK (AGE <= 100);

--6. find the count of employees whose salary is less than 3000
SELECT COUNT(*) FROM emp_data WHERE SALARY < 3000;

--7. find all details of employees whose salary is more than 2000
SELECT * FROM emp_data WHERE SALARY > 2000;

--8. find  the highest and lowest salary of employees along with their name
SELECT NAME,SALARY FROM  emp_data where 
SALARY = (select max(SALARY) from emp_data) OR 
SALARY = (select min(SALARY) from emp_data);

SELECT NAME, SALARY FROM emp_data
WHERE SALARY in ( 
  select min(SALARY) sal from emp_data 
    union 
  select max(SALARY) from emp_data);

--9. find all details of the employee whose age is more than 19
SELECT * FROM emp_data WHERE AGE > 19

--10. find the count of each name
SELECT NAME, COUNT(*) FROM emp_data GROUP BY NAME;

--11. change the id of the salary of only one Ashish to 2000
UPDATE emp_data SET SALARY = 2000
WHERE NAME = 'Ashish' AND SI_NO = 5;
SELECT * FROM emp_data

--12. change the age of the employee whoes id is 5
UPDATE emp_data SET AGE = 21
WHERE SI_NO = 5;
SELECT * FROM emp_data