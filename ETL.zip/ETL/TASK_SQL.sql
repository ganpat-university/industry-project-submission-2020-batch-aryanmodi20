-- Given above is a table with random dates inserted. The challenge here is to get the date of SUNDAY of that week which occurred prior to the given date. 
-- DROP TABLE task1
CREATE TABLE task1(
	curr_date  DATE,
	pre_sun    DATE
);

INSERT INTO task1 VALUES
('2024-03-28' , null),
('2024-02-28' , NULL),
('2024-03-08' , NULL),
('2024-02-08' , NULL);

SELECT * FROM task1

SELECT DATEADD(DAY, -((DATEPART(WEEKDAY, curr_date) + 5) % 7 + 1), curr_date) AS PRE
FROM task1


SELECT curr_date , DATEADD(DAY, -((DATEPART(WEEKDAY, curr_date)- 1)), curr_date) AS PRE
FROM task1


-- Jan Beginning will be considered as 0 by default. And the Type A, B and C rows will have random values for all the columns.
-- DROP TABLE Task2
CREATE TABLE Task2(
	months varchar(5),
	types varchar(5),
	amt int
);
-- TRUNCATE TABLE Task2
INSERT INTO Task2 VALUES
('JAN','T1',455),
('JAN','T2',85),
('JAN','T3',665),
('FEB','T1',546),
('FEB','T2',45),
('FEB','T3',55),
('MAR','T1',11),
('MAR','T2',76),
('MAR','T3',987);

SELECT * FROM Task2;


SELECT 
    types,
    [JAN] AS jan,
    [FEB] AS feb,
    [MAR] AS mar
FROM 
    (SELECT months, types, amt FROM Task2) AS SourceTable
PIVOT
    (
    MAX(amt)
    FOR months IN ([JAN], [FEB], [MAR])
    ) AS PivotTable;


	---------------
DECLARE @cols AS NVARCHAR(MAX),
        @query  AS NVARCHAR(MAX);

-- Define the desired order of months
SET @cols = 'JAN, FEB, MAR';

-- Construct the dynamic pivot query
SET @query = 
    'SELECT types, ' + @cols + ' 
    FROM 
    (
        SELECT months, types, amt
        FROM Task2
    ) AS SourceTable
    PIVOT 
    (
        MAX(amt)
        FOR months IN (' + @cols + ')
    ) AS PivotTable';

-- Execute the dynamic query
EXEC(@query);




-- Generate "op_bal" and "cl_bal" rows using UNION ALL
WITH Balances AS (
    SELECT 'op_bal' AS types, months, LAG(SUM(amt), 1, 0) OVER (ORDER BY 
                                    CASE WHEN months = 'JAN' THEN 0 ELSE 1 END, months) AS amt 
    FROM Task2 GROUP BY months
    UNION ALL
    SELECT 'cl_bal' AS types, months, SUM(amt) + LAG(SUM(amt), 1, 0) OVER (ORDER BY 
                                    CASE WHEN months = 'JAN' THEN 0 ELSE 1 END, months) AS amt 
    FROM Task2 GROUP BY months
)
-- Pivot the data including "op_bal" and "cl_bal"
SELECT 
    types,
    [JAN], [FEB], [MAR]
FROM 
    (
        SELECT 
            types,
            months,
            amt
		FROM 
            Task2
        UNION ALL
        SELECT 
            types,
            months,
            amt
        FROM 
            Balances
    ) AS SourceTable
PIVOT
    (
    SUM(amt)
    FOR months IN ([JAN], [FEB], [MAR])
    ) AS PivotTable
ORDER BY 
    CASE types
        WHEN 'op_bal' THEN 0
        WHEN 't1' THEN 1
        WHEN 't2' THEN 2
        WHEN 't3' THEN 3
        WHEN 'cl_bal' THEN 4
    END;

--------------------------------------
WITH MonthlySummary AS (
    SELECT 
        months,
        types,
        amt,
        SUM(amt) OVER (PARTITION BY months ORDER BY types) AS RunningTotal
    FROM Task2
)
SELECT 
    'op_bal' AS types,
    0 AS Jan,
    SUM(CASE WHEN months = 'JAN' THEN amt ELSE 0 END) AS Feb,
    SUM(CASE WHEN months = 'FEB' THEN amt ELSE 0 END) + SUM(CASE WHEN months = 'JAN' THEN amt ELSE 0 END) AS Mar
FROM MonthlySummary
UNION ALL
SELECT 
    'T1' AS types,
    SUM(CASE WHEN types = 'T1' THEN amt ELSE 0 END) AS Jan,
    SUM(CASE WHEN types = 'T1' THEN amt ELSE 0 END) AS Feb,
    SUM(CASE WHEN types = 'T1' THEN amt ELSE 0 END) AS Mar
FROM Task2
UNION ALL
SELECT 
    'T2' AS types,
    SUM(CASE WHEN types = 'T2' THEN amt ELSE 0 END) AS Jan,
    SUM(CASE WHEN types = 'T2' THEN amt ELSE 0 END) AS Feb,
    SUM(CASE WHEN types = 'T2' THEN amt ELSE 0 END) AS Mar
FROM Task2
UNION ALL
SELECT 
    'T3' AS types,
    SUM(CASE WHEN types = 'T3' THEN amt ELSE 0 END) AS Jan,
    SUM(CASE WHEN types = 'T3' THEN amt ELSE 0 END) AS Feb,
    SUM(CASE WHEN types = 'T3' THEN amt ELSE 0 END) AS Mar
FROM Task2
UNION ALL
SELECT 
    'cl+bal' AS types,
    SUM(CASE WHEN months = 'JAN' THEN amt ELSE 0 END) AS Jan,
    SUM(CASE WHEN months = 'FEB' THEN amt ELSE 0 END) + SUM(CASE WHEN months = 'JAN' THEN amt ELSE 0 END) AS Feb,
    SUM(CASE WHEN months = 'MAR' THEN amt ELSE 0 END) + SUM(CASE WHEN months = 'FEB' THEN amt ELSE 0 END) + SUM(CASE WHEN months = 'JAN' THEN amt ELSE 0 END) AS Mar
FROM MonthlySummary;

