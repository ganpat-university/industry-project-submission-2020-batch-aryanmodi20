-- Create table
CREATE TABLE split_data (
    incoming_data VARCHAR(20)
);

INSERT INTO split_data (incoming_data) VALUES 
('a1,b1,c1'),
('a2,b2'),
('a3,b3,c3,d3'),
('a4,b4,c4,d4,e4'),
('c5,d5,e5');

SELECT * From split_data
-------------------------------------------------------------------------------------
-- TEST DATA
CREATE TABLE SPLIT_DATA_test(INCOMING_DATA VARCHAR(MAX));
INSERT INTO SPLIT_DATA_test VALUES('A1,B1,C1'),('A2,B2'),('A3,B3,C3,D3'),('A4,B4,C4,D4,E4'),('C5,D5,E5');
SELECT * FROM SPLIT_DATA_test;

 
SELECT INCOMING_DATA,
ISNULL([phn1],'') AS [phn1], 
ISNULL([phn2],'') AS [phn2], 
ISNULL([phn3],'') AS [phn3], 
ISNULL([phn4],'') AS [phn4],
ISNULL([phn5],'') AS [phn5] 
FROM ( 
SELECT INCOMING_DATA, 
'phn'+ CAST(ROW_NUMBER()OVER(PARTITION BY incoming_data ORDER BY INCOMING_DATA ) AS VARCHAR) AS Col, 
Split.value 
FROM SPLIT_DATA_test AS SD 
CROSS APPLY String_split(INCOMING_DATA,',') AS Split 
) 
AS tbl
Pivot (Max(Value) FOR col IN ([phn1],[phn2],[phn3],[phn4],[phn5])
) AS Pvt
--------------------------------------------------------------------------------------
SELECT incoming_data,  
ISNULL([col1],'NULL') AS [col1], 
ISNULL([col2],'NULL') AS [col2], 
ISNULL([col3],'NULL') AS [col3], 
ISNULL([col4],'NULL') AS [col4],
ISNULL([col5],'NULL') AS [col5]
FROM ( 
 SELECT incoming_data, 'col'+ CAST(ROW_NUMBER()OVER(PARTITION BY incoming_data ORDER BY incoming_data) AS VARCHAR) AS Col, value 
 FROM split_data AS sd 
 CROSS APPLY String_split(incoming_data,',') AS Split 
 ) AS tbl
Pivot (Max(Value) FOR Col IN ([col1],[col2],[col3],[col4],[col5])
) AS Pvt


/* SELECT 
    incoming_data,
    MAX(CASE WHEN Col = 'col1' THEN value ELSE '' END) AS col1,
    MAX(CASE WHEN Col = 'col2' THEN value ELSE '' END) AS col2,
    MAX(CASE WHEN Col = 'col3' THEN value ELSE '' END) AS col3,
    MAX(CASE WHEN Col = 'col4' THEN value ELSE '' END) AS col4,
    MAX(CASE WHEN Col = 'col5' THEN value ELSE '' END) AS col5
FROM (
    SELECT incoming_data,
           CONCAT('incoming_data', ROW_NUMBER() OVER (PARTITION BY incoming_data ORDER BY incoming_data)) AS Col,
           value 
    FROM split_data AS sd 
    CROSS JOIN STRING_SPLIT(incoming_data, ',')
) AS tbl
GROUP BY incoming_data, Col;*/

DECLARE @cols AS NVARCHAR(MAX), @query AS NVARCHAR(MAX);

-- Get the distinct column names dynamically
SELECT @cols = STUFF((SELECT ',' + QUOTENAME('col' + CAST(ROW_NUMBER() OVER (PARTITION BY incoming_data ORDER BY incoming_data) AS VARCHAR))
            FROM split_data
            FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 1, '');

-- Dynamic SQL query
SET @query = '
SELECT incoming_data
FROM (
    SELECT incoming_data, ''col'' + CAST(ROW_NUMBER() OVER (PARTITION BY incoming_data ORDER BY incoming_data) AS VARCHAR) AS Col, value
    FROM split_data AS sdbbb
    CROSS APPLY STRING_SPLIT(incoming_data, '', '') AS Split
) AS tbl
PIVOT (
    MAX(Value) FOR Col IN (' + @cols + ')
) AS Pvt';

-- Execute the dynamic SQL query
EXEC sp_executesql @query;

DROP PROCEDURE DynamicPivotWithNullReplacement

CREATE PROCEDURE DynamicPivotWithNullReplacement
AS
BEGIN
    DECLARE @cols AS NVARCHAR(MAX), @query AS NVARCHAR(MAX);

    -- Get the distinct column names dynamically
    SELECT @cols = STUFF((SELECT ',' + QUOTENAME('col' + CAST(ROW_NUMBER() OVER (PARTITION BY incoming_data ORDER BY incoming_data) AS VARCHAR))
                FROM split_data
                FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 1, '');

    -- Dynamic SQL query
    SET @query = '
    DECLARE @PivotResult TABLE (
        incoming_data NVARCHAR(MAX),
        ' + 
        STUFF((SELECT ',' + QUOTENAME('col' + CAST(ROW_NUMBER() OVER (PARTITION BY incoming_data ORDER BY incoming_data) AS VARCHAR)) + ' NVARCHAR(MAX)'
               FROM split_data
               FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 1, '') + '
    );

    INSERT INTO @PivotResult
    SELECT incoming_data, ' + 
            STUFF((SELECT ',' + 'ISNULL(' + QUOTENAME('col' + CAST(ROW_NUMBER() OVER (PARTITION BY incoming_data ORDER BY incoming_data) AS VARCHAR)) + ', '''')'
                   FROM split_data
                   FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 1, '') + '
    FROM (
        SELECT incoming_data, ''col'' + CAST(ROW_NUMBER() OVER (PARTITION BY incoming_data ORDER BY incoming_data) AS VARCHAR) AS Col, value
        FROM split_data AS sd
        CROSS APPLY STRING_SPLIT(incoming_data, '', '') AS Split
    ) AS tbl
    PIVOT (
        MAX(Value) FOR Col IN (' + @cols + ')
    ) AS Pvt;

    -- Select from the table variable
    SELECT * FROM @PivotResult;';

    -- Execute the dynamic SQL query
    EXEC sp_executesql @query;
END;


EXEC DynamicPivotWithNullReplacement;


-- Drop table if exists
IF OBJECT_ID('tempdb..#split_data') IS NOT NULL
    DROP TABLE #split_data;
--------------------------------------------------------------------------
-- CORRECT
-- Create temporary table
CREATE TABLE #split_data (
    incoming_data VARCHAR(20)
);

-- Insert data
INSERT INTO #split_data (incoming_data) VALUES 
('a1,b1,c1'),
('a2,b2'),
('a3,b3,c3,d3'),
('a4,b4,c4,d4,e4'),
('c5,d5,e5');
go
select * from #split_data
-- Dynamic SQL to pivot the data
DECLARE @cols AS NVARCHAR(MAX), @query AS NVARCHAR(MAX);

-- Generate dynamic column names
SELECT @cols = STUFF((SELECT DISTINCT ',' + QUOTENAME('col' + CAST(ROW_NUMBER() OVER (PARTITION BY incoming_data ORDER BY incoming_data) AS VARCHAR(10)))
            FROM #split_data
            CROSS APPLY STRING_SPLIT(incoming_data, ',')
            FOR XML PATH('')), 1, 1, '');
print @cols

-- Dynamic SQL query
SET @query = 
    'SELECT incoming_data, ' + @cols + '
    FROM (
        SELECT incoming_data, ''col'' +CAST(ROW_NUMBER()OVER(PARTITION BY incoming_data ORDER BY incoming_data) AS VARCHAR) AS Col, value 
		FROM split_data AS sd 
		CROSS APPLY String_split(incoming_data,'','') AS Split 
    ) AS tbl
    PIVOT (
        MAX(Value) FOR Col IN (' + @cols + ')
    ) AS Pvt';

-- Execute dynamic SQL
EXEC sp_executesql @query;
