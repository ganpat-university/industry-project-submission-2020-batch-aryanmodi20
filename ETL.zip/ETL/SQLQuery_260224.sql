CREATE TABLE seq_tab(
	T_NO VARCHAR(5),
	A  INT,
	B  INT,
	C  INT
);

INSERT INTO seq_tab VALUES
('T1',2,1,2),
('T1',1,2,2),
('T1',2,1,1),
('T2',2,2,2),
('T2',2,2,2),
('T2',1,1,2);

SELECT * FROM seq_tab;


WITH Sequences AS (
    SELECT
        T_NO,
        CASE
            WHEN A = LAG(A) OVER (PARTITION BY T_NO ORDER BY (SELECT 1)) THEN 1
            ELSE 0
        END AS A_Seq,
        CASE
            WHEN B = LAG(B) OVER (PARTITION BY T_NO ORDER BY (SELECT 1)) THEN 1
            ELSE 0
        END AS B_Seq,
        CASE
            WHEN C = LAG(C) OVER (PARTITION BY T_NO ORDER BY (SELECT 1)) THEN 1
            ELSE 0
        END AS C_Seq
    FROM seq_tab
)
SELECT T_NO, sum(A_Seq) AS T_A, sum(B_Seq) AS T_B , sum(C_Seq) AS T_B
FROM Sequences
GROUP BY T_NO;

-------------------------------------------------------------
 CREATE TABLE train_details(train_no INT, station VARCHAR(200), Timing TIME); 

 INSERT INTO train_details(train_no , station , Timing) 
 VALUES(22863,'Howrah','10:50:00'),
 (22863 ,'Kharagpur','12:30:00'),
 (22863 ,'Balasore','13:52:00'),
 (22863 ,'Cuttack','15:47:00'),
 (22863 ,'Bhubaneswar','16:25:00'),
 (12262 ,'Howrah','05:45:00'),
 (12262 ,'Tatanagar','09:00:00'),
 (12262 ,'Bilaspur','15:05:00'),
(12262 ,'Raipur','16:37:00'),
(12262 ,'Nagpur','20:55:00');

select * from train_details;


-- time to next station
SELECT A.train_no , A.station , A.Timing, concat(FLOOR((nxt_st_time%86400)/3600) , ' hr ' ,FLOOR((nxt_st_time%3600)/60), ' min ',FLOOR((nxt_st_time%3600)/60), ' sec ')
from(
SELECT * , datediff(second, timing ,LEAD(TIMING) over(partition by train_no order by timing)) as nxt_st_time  FROM train_details
) A


-- elapsed time till now
SELECT A.train_no , A.station , A.Timing, concat(FLOOR((nxt_st_time%86400)/3600) , ' hr ' ,FLOOR((nxt_st_time%3600)/60), ' min ',FLOOR((nxt_st_time%3600)/60), ' sec ') as elapsed_time
from(
SELECT * , datediff(second, min(TIMING) over(partition by train_no order by timing), Timing) as nxt_st_time  FROM train_details
) A
-------------------------------------------
