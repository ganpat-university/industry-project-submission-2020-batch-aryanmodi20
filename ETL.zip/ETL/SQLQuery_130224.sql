--DROP TABLE interval_date

CREATE TABLE interval_date(
	sub_id int ,
	nxt_bill_date date,
	interval int 
);

INSERT INTO interval_date VALUES
(1 , '2021-01-12' , 2),
(2 , '2021-01-15' , 7),
(3 , '2021-01-15' , 3),
(5 , '2021-02-11' , 4);

-- DROP TABLE RecursiveDates

CREATE TABLE RecursiveDates(
	id int ,
	nxt_dt date
);

SELECT * FROM interval_date;
SELECT * FROM RecursiveDates;


-----------------------------------------------------------
-- CORRECT
select ROW_NUMBER() over(order by(select 1)) RW, sub_id, nxt_bill_date, interval into temp from interval_date;
 
Declare @var1 int, @var2 date, @var3 int, @i int, @var4 date;
Set @i = 1;

WHILE @i <= (select COUNT(*) from interval_date)
begin
set @var1 = (select sub_id from temp where RW = @i)
set @var2 = (select nxt_bill_date from temp where RW = @i)
set @var3 = (select interval from temp where RW = @i)
set @var4 = (select nxt_bill_date from temp where RW = @i)
 
while @var2 <= EOMONTH (@var4)
begin
    insert into RecursiveDates values (@var1, @var2);
    set @var2 = dateadd(dd, @var3, @var2)
end
   SET @i = @i + 1;
end

----------------------------------------------

WITH DATE1 AS
(	SELECT SUB_ID ,NXT_BILL_DATE AS DDATE,NXT_BILL_DATE,EOMONTH(NXT_BILL_DATE) AS ENDDATE, INTERVAL FROM CTE_DATE         -- anchor
    union all 
    select SUB_ID,DDATE,DATEADD(DAY,INTERVAL,NXT_BILL_DATE),ENDDATE,INTERVAL from DATE1   -- recursive
    where NXT_BILL_DATE<=DATEADD(DAY,-INTERVAL,ENDDATE)
)
SELECT SUB_ID ,DDATE,INTERVAL,NXT_BILL_DATE FROM DATE1 ORDER BY SUB_ID,NXT_BILL_DATE



------------------------------------------------------------------------------
-- CORRECT
WITH RecursiveDates AS (
  SELECT sub_id, nxt_bill_date AS DDATE, NXT_BILL_DATE,EOMONTH(NXT_BILL_DATE) AS ENDDATE, INTERVAL
  FROM interval_date

  UNION ALL

  SELECT sub_id,DDATE , DATEADD(DAY, interval, NXT_BILL_DATE), ENDDATE,INTERVAL
  FROM RecursiveDates
  WHERE NXT_BILL_DATE<=DATEADD(DAY,-INTERVAL,ENDDATE)
)

SELECT sub_id, NXT_BILL_DATE
FROM RecursiveDates
ORDER BY sub_id, NXT_BILL_DATE;

----------------------------------------------------------------------------

go
DECLARE @endOfMonth DATE;
SELECT @endOfMonth = EOMONTH(nxt_bill_date) FROM interval_date;

WITH RecursiveDates AS (
  SELECT sub_id AS id, nxt_bill_date AS nxt_dt, 1 AS rec_level
  FROM interval_date

  UNION ALL

  SELECT r.id, DATEADD(DAY, t.interval, r.nxt_dt) AS nxt_dt, r.rec_level + 1
  FROM RecursiveDates r
  JOIN interval_date t ON r.id = t.sub_id
  WHERE DATEADD(DAY, t.interval, r.nxt_dt) <= @endOfMonth
)

SELECT id, nxt_dt
FROM RecursiveDates
ORDER BY id, nxt_dt;

