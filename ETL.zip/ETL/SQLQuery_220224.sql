CREATE TABLE CRIC_STAT (Team_1 varchar(15), Team_2 varchar(15), Winner varchar(15));
 
insert into CRIC_STAT values('India', 'Sri Lanka', 'India');
insert into CRIC_STAT values('Sri Lanka', 'Australia', 'Australia');
insert into CRIC_STAT values('South Africa', 'England', 'England');
insert into CRIC_STAT values('England', 'New Zealand', 'New Zealand');
insert into CRIC_STAT values('Australia', 'India', 'India');
 
select * from CRIC_STAT;

SELECT
  Team_Name,
  COUNT(Team_Name) AS Matches_Played,
  SUM(CASE WHEN Winner = Team_Name THEN 1 ELSE 0 END) AS No_OF_Win,
  SUM(CASE WHEN Winner <> Team_Name THEN 1 ELSE 0 END) AS No_OF_Loss
FROM(
SELECT Team_1 AS Team_Name, Winner FROM CRIC_STAT
UNION ALL
SELECT Team_2 AS Team_Name, Winner FROM CRIC_STAT
) AS Teams
GROUP BY Team_Name
ORDER BY No_OF_Win;