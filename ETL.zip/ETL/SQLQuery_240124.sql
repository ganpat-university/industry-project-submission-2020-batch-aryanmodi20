create table school_details(
	school_area varchar(20),
	school_id int
);
insert into school_details(school_area, school_id) values 
('KHARGHAR', 1), ('NERUL', 2), ('NERUL', 3),
('KHARGHAR', 4), ('NERUL', 5), ('THANE', 6),
('KHARGHAR', 7), ('THANE', 8), ('KHARGHAR', 9);

insert into school_details(school_area, school_id) values
('NERUL', 2),
('NERUL', 2),
('NERUL', 2),
('NERUL', 2),
('NERUL', 2),
('NERUL', 2);

select * from school_details

SELECT TOP 1 school_area , count(school_area) AS cnt FROM school_details GROUP BY school_area ORDER BY cnt DESC;
---------
SELECT B.SCHOOL_AREA, B.CNT FROM (
SELECT *, ROW_NUMBER() OVER (ORDER BY A.CNT DESC) AS RW FROM (
SELECT SCHOOL_AREA, COUNT(SCHOOL_AREA) AS CNT FROM school_details GROUP BY school_area
)A
)B WHERE B.RW =1



---------------------------------------------------------------------------
CREATE TABLE manager_data (
    manager_id VARCHAR(5),
    ot_hrs VARCHAR(50)
);

INSERT INTO manager_data VALUES 
('M1', '2+3+2+1+2'),
('M2', '2+3+2+1+2+3');

INSERT INTO manager_data VALUES 
('M3', '2+3+2+1+2+3+4'),
('M4', '2+3+2+1+2+3+11');

SELECT* FROM manager_data;

SELECT manager_id , CAST(value AS INT) FROM manager_data CROSS APPLY string_split(ot_hrs, '+')


SELECT manager_id, SUM(CAST(value AS INT)/2)+1 AS total_ot_hRs
FROM  manager_data
CROSS APPLY STRING_SPLIT(ot_hrs, '+')
GROUP BY manager_id;

SELECT value
FROM
STRING_SPLIT('2+3+2+1+2+3+11', '+')