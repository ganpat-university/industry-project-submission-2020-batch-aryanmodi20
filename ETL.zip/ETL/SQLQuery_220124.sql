--1. Display empno, ename, sal from emp table and give numbers to each row.
SELECT ROW_NUMBER() OVER (ORDER BY EMPLOYEE_ID) AS row_num, EMPLOYEE_ID, FIRST_NAME, SALARY
FROM employees;

--2. Display empno, ename, sal and give numbers to each row in ascending order of salary.
SELECT ROW_NUMBER() OVER (ORDER BY SALARY) AS row_num, EMPLOYEE_ID, FIRST_NAME, SALARY
FROM employees;

--3. Assign the ranks to employees in ascending order of salary.
SELECT RANK() OVER (ORDER BY SALARY) AS rank,EMPLOYEE_ID, FIRST_NAME, SALARY
FROM employees;

--4. Assign the ranks to employees in ascending order of salary using dense rank and point out the difference.
SELECT DENSE_RANK() OVER (ORDER BY SALARY) AS dense_rank, RANK() OVER (ORDER BY SALARY) AS rank, EMPLOYEE_ID, FIRST_NAME, SALARY
FROM employees;

--5. Assign the ranks to employees in ascending order of salary but display records in descending order of salary.
SELECT RANK() OVER (ORDER BY SALARY ASC) AS rank,EMPLOYEE_ID, FIRST_NAME, SALARY
FROM employees
ORDER BY SALARY DESC;

--6. Assign the rank to emp table rows in the ascending order of department and salary.
SELECT RANK() OVER (PARTITION BY DEPARTMENT_ID ORDER BY SALARY) AS rank, EMPLOYEE_ID, FIRST_NAME, SALARY
FROM employees;

--7. Assign the rank to emp table rows in the ascending order of department and descending order of salary.
SELECT RANK() OVER (PARTITION BY DEPARTMENT_ID ORDER BY SALARY DESC) AS rank, EMPLOYEE_ID, FIRST_NAME, SALARY, DEPARTMENT_ID
FROM employees;

--8. Calculate the ranks of employee for each department according to sal.
SELECT DENSE_RANK() OVER (PARTITION BY DEPARTMENT_ID ORDER BY SALARY) AS dense_rank,EMPLOYEE_ID, FIRST_NAME, SALARY, DEPARTMENT_ID
FROM employees;

--9. For the above query use dense_rank() and point out the difference.
SELECT RANK() OVER (PARTITION BY DEPARTMENT_ID ORDER BY SALARY) AS rank, DENSE_RANK() OVER (PARTITION BY DEPARTMENT_ID ORDER BY SALARY) AS dense_rank, EMPLOYEE_ID, FIRST_NAME, SALARY, DEPARTMENT_ID
FROM employees;

--10. Calculate the ranks of employee for each department &amp; display only top 2 high salaried employees for each of them.
WITH RankedEmployees AS (
    SELECT EMPLOYEE_ID, FIRST_NAME, SALARY, DENSE_RANK() OVER (PARTITION BY DEPARTMENT_ID ORDER BY SALARY DESC) AS SalaryRank
    FROM employees
)
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY
FROM RankedEmployees
WHERE SalaryRank <= 2;
----
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY FROM (
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY, DENSE_RANK() OVER (PARTITION BY DEPARTMENT_ID ORDER BY SALARY DESC) AS SalaryRank
FROM employees
)A where salaryRank <=2

--11. Find out top 3 low salaried employees for each department.
WITH RankedEmployees AS (
    SELECT EMPLOYEE_ID, FIRST_NAME, SALARY, DENSE_RANK() OVER (PARTITION BY DEPARTMENT_ID ORDER BY SALARY ASC) AS SalaryRank
    FROM employees
)
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY
FROM RankedEmployees
WHERE SalaryRank <= 3;
----
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY FROM (
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY, DENSE_RANK() OVER (PARTITION BY DEPARTMENT_ID ORDER BY SALARY ASC) AS SalaryRank
FROM employees
) A WHERE SalaryRank <=3

--12. Find out top 2 low salaried employees.
WITH RankedEmployees AS (
    SELECT EMPLOYEE_ID, FIRST_NAME, SALARY, DENSE_RANK() OVER (ORDER BY SALARY ASC) AS SalaryRank
    FROM employees
)
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY
FROM RankedEmployees
WHERE SalaryRank <= 2;
---
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY FROM (
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY, DENSE_RANK() OVER (ORDER BY SALARY ASC) AS SalaryRank
FROM employees
) A WHERE SalaryRank <= 2; 

--13. Find information of employee who is having lowest sal in each department.
WITH RankedEmployees AS (
    SELECT EMPLOYEE_ID, FIRST_NAME, SALARY, DENSE_RANK() OVER (PARTITION BY DEPARTMENT_ID ORDER BY SALARY ASC) AS SalaryRank
    FROM employees
)
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY
FROM RankedEmployees
WHERE SalaryRank <= 1;
---
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY FROM (
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY, DENSE_RANK() OVER (PARTITION BY DEPARTMENT_ID ORDER BY SALARY ASC) AS SalaryRank
FROM employees
) A WHERE SalaryRank <= 1;

--14. Assign row numbers in desc order of salary. Display the records in asc order of commission and null values of commission should come last.
WITH RankedEmployees AS (
    SELECT EMPLOYEE_ID, FIRST_NAME, SALARY, COMMISSION_PCT ,  ROW_NUMBER() OVER (ORDER BY SALARY DESC) AS SalaryRowNum
    FROM employees
)
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY
FROM RankedEmployees
ORDER BY COMMISSION_PCT  ASC;
---
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY FROM (
SELECT EMPLOYEE_ID, FIRST_NAME, SALARY, COMMISSION_PCT ,  ROW_NUMBER() OVER (ORDER BY SALARY DESC) AS SalaryRowNum
FROM employees
) A ORDER BY COMMISSION_PCT  ASC;

---
--15. Display empno, ename, sal, comm., in desc order of comm. And replace all 0.00 values of comm. by 8888.
SELECT DEPARTMENT_ID, FIRST_NAME, SALARY, CASE WHEN COMMISSION_PCT = 0.00 THEN 8888 ELSE COMMISSION_PCT END AS commi
FROM employees
ORDER BY commi DESC;


--16. Display empname, job &amp; sal. Give ranking to sal job wise.
SELECT JOB_ID ,EMPLOYEE_ID, FIRST_NAME, SALARY, RANK() OVER (PARTITION BY JOB_ID ORDER BY SALARY) AS job_rank
FROM employees;

--17. Display the details of all salesman using dense rank on ascending order of salary.
SELECT DENSE_RANK() OVER (ORDER BY SALARY ASC) AS dense_rank, EMPLOYEE_ID, FIRST_NAME, SALARY, JOB_ID
FROM employees
WHERE JOB_ID = 'SA_MAN';

--18. Display first 5 records of employee in descending order of salary.
SELECT TOP 5 *
FROM employees
ORDER BY SALARY DESC;

--19. Display first 5 records of employee in ascending order of salary, replace null values of comm. by zero
SELECT TOP 5 EMPLOYEE_ID, FIRST_NAME, SALARY, ISNULL(COMMISSION_PCT, 0) AS commi
FROM employees
ORDER BY COMMISSION_PCT ASC;

