CREATE TABLE emp_data_agg(
	EmployeeID int PRIMARY KEY,
	Ename varchar(15),
	DeptID int,
	Salary int
);
INSERT INTO emp_data_agg(EmployeeID , Ename , DeptID ,Salary)
VALUES ('1001', 'John', 2,4000),
       ('1002', 'Anna', 1,3500),
       ('1003', 'James', 1,2500),
       ('1004', 'David', 2,5000),
	   ('1005', 'Mark', 2,3000),
       ('1006', 'Steve', 3,4500),
	   ('1007', 'Alice', 3,3500);

SELECT *FROM emp_data_agg;

--1. Average salary of all employees:
SELECT AVG(Salary) AS Avg_Salary FROM emp_data_agg;

--2. Total salary paid to all employees:
SELECT SUM(Salary) AS Tot_salary FROM emp_data_agg;

--3. Highest salary of employees with their name:
SELECT Ename , Salary FROM emp_data_agg Where Salary = (SELECT MAX(Salary) FROM emp_data_agg);

--4. Lowest salary of employees with their name:
SELECT Ename , Salary FROM emp_data_agg Where Salary = (SELECT MIN(Salary) FROM emp_data_agg);

--5. Total salary paid in each department:
SELECT DeptID , SUM(Salary) AS Tot_sal_by_Dep FROM emp_data_agg Group BY DeptID;

--6. Number of employees in each department:
SELECT DeptID , COUNT(DeptID) AS cnt_emp_dep FROM emp_data_agg Group BY DeptID;

--7. Count of employees earning a salary above 4000:
SELECT COUNT(*) AS Emp_abv_4000 FROM emp_data_agg WHERE Salary > 4000;

--8. Average salary of employees in department 2:
SELECT AVG(Salary) AS Avg_sal_Dept2 FROM emp_data_agg WHERE DeptID = 2;

--9. Maximum salary of employees with names starting with 'A':
SELECT Max(Salary) AS Avg_sal_ANames FROM emp_data_agg WHERE Ename LIKE 'A%';

--10. UPPER 


--11. TRIM
--12. RTRIM
--13. LOWER
--14. LEN
--15. LEFT
--16. RIGHT
--17. CONCAT
--18. BETWEEN
--19. IN
--20. AND
--21. OR
--22. SUBSTRING