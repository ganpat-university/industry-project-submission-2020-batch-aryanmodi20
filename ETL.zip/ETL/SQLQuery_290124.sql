CREATE TABLE src_table(
	empid int,
	emp_name VARCHAR(10),
	company_join_data date,
	company_id int
);

INSERT INTO src_table VALUES
(1 , 'Sahana' , '2022-03-10' ,1),
(1 , 'Sahana' , '2020-02-15' ,2),
(2 , 'Faisal' , '2022-03-12' ,3);

SELECT * FROM src_table


CREATE TABLE company_table(
	company_id int,
	company_name VARCHAR(10)
);

INSERT INTO company_table VALUES
(1 , 'Google'),
(2 , 'Veracitiz'),
(3 , 'Infosys');

SELECT * FROM company_table


CREATE TABLE existing_target(
	empid int,
	emp_name VARCHAR(10),
	company_name VARCHAR(10),
	join_dt date
);

INSERT INTO existing_target VALUES
(1 , 'Sahana' , 'Veracitiz' ,'20200215'),
(2 , 'Faisal' , null ,null);

SELECT * FROM existing_target
SELECT * FROM src_table
SELECT * FROM company_table


SELECT empid,emp_name,company_name,company_join_data INTO source_table
FROM src_table as s
JOIN company_table as c
on s.company_id=c.company_id

SELECT * FROM source_table
SELECT * FROM existing_target

DELETE FROM source_table WHERE company_name = 'Veracitiz'

MERGE existing_target AS target
USING source_table AS source
on target.empid = source.empid
WHEN MATCHED 
	THEN UPDATE
		SET company_name = source.company_name,
		    join_dt = source.company_join_data;

SELECT * FROM existing_target

--------------------------------------------------------------------------

SELECT * FROM source_table
SELECT * FROM existing_target
SELECT * FROM src_table
SELECT * FROM company_table

INSERT INTO src_table VALUES
(1 , 'Sahana' , '2024-01-29' ,4),
(2 , 'Rahul' , '2020-02-15' ,3),
(3 , 'Meena' , '2011-03-12' ,2);

INSERT INTO company_table VALUES
(4 , 'Microsoft');

SELECT * FROM src_table
SELECT * FROM company_table

SELECT empid,emp_name,company_name,company_join_data INTO source_table_new
FROM src_table as s
JOIN company_table as c
on s.company_id=c.company_id

SELECT * FROM source_table_new

SELECT empid , emp_name, company_name, company_join_data INTO final_source
FROM (
SELECT empid, emp_name, company_name,company_join_data, row_number() OVER(PARTITION BY empid ORDER BY company_join_data DESC) as rd FROM source_table_new
)A WHERE A.rd =1

SELECT * FROM final_source


SELECT * FROM final_source
SELECT * FROM existing_target

MERGE existing_target AS target
USING final_source AS source
on target.empid = source.empid
WHEN MATCHED 
	THEN UPDATE
		SET company_name = source.company_name,
		    join_dt = source.company_join_data 

WHEN NOT MATCHED
	THEN INSERT(empid,emp_name,company_name,Join_dt)
		VALUES(source.empid,source.emp_name,source.company_name,source.company_join_data);

SELECT * FROM existing_target