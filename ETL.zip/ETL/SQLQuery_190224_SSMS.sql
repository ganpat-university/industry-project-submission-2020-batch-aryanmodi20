DROP table recomendation_sys
create table recomendation_sys(id int, verticals varchar(20),
service_line varchar(20), customer varchar(20),
product varchar(20));
 
insert into recomendation_sys values
(1, 'clothing', 'summer', 'prada', 'shirt'),
(2, 'clothing', 'summer', 'zara', 'pants'),
(3, 'clothing', 'summer', 'zara', 'shirt'),
(4, 'clothing', 'summer', 'zara', 'jeans'),
(5, 'clothing', 'summer', 'gucci', 'jeans'),
(6, 'clothing', 'summer', 'gucci', 'caps'),
(7, 'clothing', 'summer', 'gucci', 'pants'),
(8, 'clothing', 'summer', 'gucci', 'shades'),
(9, 'clothing', 'summer', 'gucci', 'jeans'),
(10, 'footwear', 'rainy', 'nike', 'flipflops'),
(11, 'footwear', 'rainy', 'nike', 'sandals'),
(12, 'footwear', 'rainy', 'nike', 'slipers'),
(13, 'footwear', 'rainy', 'adidas', 'flipflops'),
(14, 'footwear', 'rainy', 'adidas', 'boots'),
(15, 'footwear', 'rainy', 'adidas', 'sneakers'),
(16,'footwear', 'rainy', 'puma', 'sneakers'),
(17, 'clothing', 'winter', 'h&m', 'jacket'),
(18, 'clothing', 'winter', 'h&m', 'scarfs'),
(19, 'clothing', 'winter', 'h&m', 'hoodie'),
(20, 'clothing', 'winter', 'armani', 'jacket'),
(21, 'clothing', 'winter', 'armani', 'coats'),
(22, 'clothing', 'winter', 'armani', 'muffler'),
(23, 'clothing', 'winter', 'lv', 'coats'),
(24, 'sports', 'football', 'underarmour', 'studds'),
(25, 'sports', 'football', 'underarmour', 'jersys'),
(26, 'sports', 'football', 'underarmour', 'socks'),
(27, 'sports', 'football', 'newbalance', 'studds'),
(28, 'sports', 'football', 'newbalance', 'jersys'),
(29, 'sports', 'football', 'newbalance', 'shorts'),
(30, 'sports', 'football', 'newbalance', 'inner'),
(31, 'sports', 'football', 'skechers', 'shorts'),
(32, 'sports', 'football', 'skechers', 'shorts'),
(33, 'clothing', 'winter', 'lv', 'scarfs');
 
select * from recomendation_sys;


DROP PROCEDURE RecommendProductsByCustomer
-- Set delimiter for SSMS
GO

-- Create procedure
CREATE PROCEDURE RecommendProductsByCustomer
    @input_customer VARCHAR(50)
AS
BEGIN
    -- Declare variables
    DECLARE @verticals VARCHAR(20);
    DECLARE @service_line VARCHAR(20);

    -- Select verticals and service_line into variables
    SELECT @verticals = verticals, @service_line = service_line
    FROM recomendation_sys
    WHERE customer = @input_customer;

    -- Check if customer and vertical/service line exist
    IF (@verticals IS NULL OR @service_line IS NULL)
    BEGIN
        PRINT 'Customer or vertical/service line not found';
        RETURN; -- Exit the procedure
    END;


	SELECT distinct(product) FROM recomendation_sys WHERE product NOT IN 
	(SELECT product FROM recomendation_sys WHERE customer = @input_customer) AND 
	verticals IN (SELECT verticals FROM recomendation_sys WHERE customer = @input_customer) AND 
	service_line IN (SELECT service_line FROM recomendation_sys WHERE customer = @input_customer)
	END
GO
-- Execute the stored procedure
EXEC RecommendProductsByCustomer @input_customer = 'zara';

SELECT * FROM recomendation_sys WHERE customer = 'nike'
SELECT * FROM recomendation_sys WHERE customer = 'adidas'
SELECT * FROM recomendation_sys WHERE customer = 'puma'



WITH    
odd_num_cte (id, n) AS    
(    
SELECT 9, 6    
UNION ALL    
SELECT id+5, n+2 from odd_num_cte where id > 5     
)    
SELECT * FROM odd_num_cte;