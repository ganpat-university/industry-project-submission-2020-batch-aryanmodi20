-- DROP TABLE TEAM_HRE
CREATE TABLE TEAM_HRE(
		EMP_NO INT,
		EMP_NAME VARCHAR(20),
		TEAM_LEADER VARCHAR(20)
);
 
INSERT INTO TEAM_HRE VALUES
(100,'JACKY',NULL),
(101,'VRUSHABH','JACKY'),
(102,'SHIVAM','VRUSHABH'),
(103,'DURGA','SHIVAM'),
(104,'EDVIN','DURGA'),
(105,'ARYAN','EDVIN'),
(106,'ADITYA','VRUSHABH');

SELECT * FROM TEAM_HRE

----------------------------------------------
-- Hierarchy Split
WITH TeamHierarchy AS (
    SELECT EMP_NO, EMP_NAME, TEAM_LEADER, CAST(EMP_NAME AS VARCHAR(MAX)) AS TeamChain
    FROM TEAM_HRE
    WHERE TEAM_LEADER IS NULL
    
    UNION ALL
    
    SELECT t.EMP_NO, t.EMP_NAME, t.TEAM_LEADER, t.EMP_NAME + ',' + th.TeamChain
    FROM TEAM_HRE t
    INNER JOIN TeamHierarchy th ON t.TEAM_LEADER = th.EMP_NAME
)
SELECT EMP_NO, EMP_NAME, TEAM_LEADER, TeamChain
FROM TeamHierarchy
ORDER BY EMP_NO;



WITH TeamHierarchy AS (
    SELECT EMP_NO, EMP_NAME, TEAM_LEADER, CAST(EMP_NAME AS VARCHAR(MAX)) AS TeamChain
    FROM TEAM_HRE
    WHERE TEAM_LEADER IS NULL
    
    UNION ALL
    
    SELECT t.EMP_NO, t.EMP_NAME, t.TEAM_LEADER, t.EMP_NAME + ',' + th.TeamChain
    FROM TEAM_HRE t
    INNER JOIN TeamHierarchy th ON t.TEAM_LEADER = th.EMP_NAME
)

SELECT EMP_NO, EMP_NAME ,TEAM_LEADER,
       ISNULL([col1],'NULL') AS [col1], 
       ISNULL([col2],'NULL') AS [col2], 
       ISNULL([col3],'NULL') AS [col3], 
       ISNULL([col4],'NULL') AS [col4],
       ISNULL([col5],'NULL') AS [col5],
       ISNULL([col6],'NULL') AS [col6]

FROM ( 
    SELECT EMP_NO, EMP_NAME, TEAM_LEADER, TeamChain,
           'col'+ CAST(ROW_NUMBER()OVER(PARTITION BY TeamChain ORDER BY TeamChain) AS VARCHAR) AS Col, 
           value 
    FROM TeamHierarchy AS sd 
    CROSS APPLY String_split(TeamChain,',') AS Split 
) AS tbl
PIVOT (
    Max(Value) FOR Col IN ([col1],[col2],[col3],[col4],[col5],[col6])
) AS Pvt
ORDER BY EMP_NO;



	WITH TeamHierarchy AS (
		SELECT EMP_NO, EMP_NAME, TEAM_LEADER, CAST(EMP_NAME AS VARCHAR(MAX)) AS TeamChain
		FROM TEAM_HRE
		WHERE TEAM_LEADER IS NULL
    
		UNION ALL
    
		SELECT t.EMP_NO, t.EMP_NAME, t.TEAM_LEADER, t.EMP_NAME + ',' + th.TeamChain
		FROM TEAM_HRE t
		INNER JOIN TeamHierarchy th ON t.TEAM_LEADER = th.EMP_NAME
	)

	SELECT EMP_NO, EMP_NAME, TEAM_LEADER,
		MAX(CASE WHEN RN = 1 THEN value END) AS col1,
		MAX(CASE WHEN RN = 2 THEN value END) AS col2,
		MAX(CASE WHEN RN = 3 THEN value END) AS col3,
		MAX(CASE WHEN RN = 4 THEN value END) AS col4,
		MAX(CASE WHEN RN = 5 THEN value END) AS col5,
		MAX(CASE WHEN RN = 6 THEN value END) AS col6
	FROM (
		SELECT EMP_NO, EMP_NAME, TEAM_LEADER, TeamChain, value,
			   ROW_NUMBER() OVER (PARTITION BY TeamChain ORDER BY TeamChain) AS RN
		FROM TeamHierarchy AS sd
		CROSS APPLY STRING_SPLIT(TeamChain, ',') AS Split
	) AS tbl
	GROUP BY EMP_NO, EMP_NAME, TEAM_LEADER
	ORDER BY EMP_NO;

-- Create a temporary table to store the CTE result
CREATE TABLE #TempTeamHierarchy (
    EMP_NO INT,
    EMP_NAME VARCHAR(MAX),
    TEAM_LEADER VARCHAR(MAX),
    TeamChain VARCHAR(MAX)
);

-- Insert data into the temporary table using the recursive CTE
WITH TeamHierarchy AS (
    SELECT EMP_NO, EMP_NAME, TEAM_LEADER, CAST(EMP_NAME AS VARCHAR(MAX)) AS TeamChain
    FROM TEAM_HRE
    WHERE TEAM_LEADER IS NULL
    
    UNION ALL
    
    SELECT t.EMP_NO, t.EMP_NAME, t.TEAM_LEADER, t.EMP_NAME + ', ' + th.TeamChain
    FROM TEAM_HRE t
    INNER JOIN TeamHierarchy th ON t.TEAM_LEADER = th.EMP_NAME
)
INSERT INTO #TempTeamHierarchy (EMP_NO, EMP_NAME, TEAM_LEADER, TeamChain)
SELECT * FROM TeamHierarchy;

DECLARE @DynamicPivotQuery AS NVARCHAR(MAX)
DECLARE @ColumnName AS NVARCHAR(MAX)

-- Get distinct TeamChain values
SELECT @ColumnName = COALESCE(@ColumnName + ', ', '') + QUOTENAME('col' + CAST(ROW_NUMBER() OVER (ORDER BY TeamChain) AS VARCHAR))
FROM (
    SELECT DISTINCT TeamChain
    FROM #TempTeamHierarchy
) AS TeamChainList

-- Construct the dynamic pivot query
SET @DynamicPivotQuery = 
    'SELECT EMP_NO, EMP_NAME, TEAM_LEADER, ' + @ColumnName + '
    FROM (
        SELECT EMP_NO, EMP_NAME, TEAM_LEADER, TeamChain, value,
            ''col'' + CAST(ROW_NUMBER() OVER (PARTITION BY TeamChain ORDER BY TeamChain) AS VARCHAR) AS ColNum
        FROM #TempTeamHierarchy AS sd
        CROSS APPLY STRING_SPLIT(TeamChain, '', '') AS Split
    ) AS src
    PIVOT (
        MAX(value) FOR ColNum IN (' + @ColumnName + ')
    ) AS Pvt
    ORDER BY EMP_NO;'

-- Execute the dynamic pivot query
EXEC sp_executesql @DynamicPivotQuery;

-- Drop the temporary table
DROP TABLE #TempTeamHierarchy;








-- Create a temporary table to store the CTE result
CREATE TABLE #TempTeamHierarchy (
    EMP_NO INT,
    EMP_NAME VARCHAR(MAX),
    TEAM_LEADER VARCHAR(MAX),
    TeamChain VARCHAR(MAX)
);

-- Insert data into the temporary table using the recursive CTE
WITH TeamHierarchy AS (
    SELECT EMP_NO, EMP_NAME, TEAM_LEADER, CAST(EMP_NAME AS VARCHAR(MAX)) AS TeamChain
    FROM TEAM_HRE
    WHERE TEAM_LEADER IS NULL
    
    UNION ALL
    
    SELECT t.EMP_NO, t.EMP_NAME, t.TEAM_LEADER, t.EMP_NAME + ', ' + th.TeamChain
    FROM TEAM_HRE t
    INNER JOIN TeamHierarchy th ON t.TEAM_LEADER = th.EMP_NAME
)
INSERT INTO #TempTeamHierarchy (EMP_NO, EMP_NAME, TEAM_LEADER, TeamChain)
SELECT * FROM TeamHierarchy;

-- View the inserted data
SELECT * FROM #TempTeamHierarchy;

-- Drop the temporary table
DROP TABLE #TempTeamHierarchy;

---------------------------------------------------------------------------

DECLARE @cols AS NVARCHAR(MAX), @query AS NVARCHAR(MAX);

-- Generate dynamic column names
SELECT @cols = STUFF((SELECT DISTINCT ',' + QUOTENAME('col' + CAST(ROW_NUMBER() OVER (PARTITION BY incoming_data ORDER BY incoming_data) AS VARCHAR(10)))
            FROM #split_data
            CROSS APPLY STRING_SPLIT(incoming_data, ',')
            FOR XML PATH('')), 1, 1, '');
print @cols

-- Dynamic SQL query
SET @query = 
    'SELECT incoming_data, ' + @cols + '
    FROM (
        SELECT incoming_data, ''col'' +CAST(ROW_NUMBER()OVER(PARTITION BY incoming_data ORDER BY incoming_data) AS VARCHAR) AS Col, value 
		FROM split_data AS sd 
		CROSS APPLY String_split(incoming_data,'','') AS Split 
    ) AS tbl
    PIVOT (
        MAX(Value) FOR Col IN (' + @cols + ')
    ) AS Pvt';

-- Execute dynamic SQL
EXEC sp_executesql @query;



DECLARE @cols AS NVARCHAR(MAX);
DECLARE @query AS NVARCHAR(MAX);

WITH TeamHierarchy AS (
    SELECT EMP_NO, EMP_NAME, TEAM_LEADER, CAST(EMP_NAME AS VARCHAR(MAX)) AS TeamChain
    FROM TEAM_HRE
    WHERE TEAM_LEADER IS NULL
    
    UNION ALL
    
    SELECT t.EMP_NO, t.EMP_NAME, t.TEAM_LEADER, t.EMP_NAME + ', ' + th.TeamChain
    FROM TEAM_HRE t
    INNER JOIN TeamHierarchy th ON t.TEAM_LEADER = th.EMP_NAME
)

SELECT @cols = STUFF((SELECT DISTINCT ',' + QUOTENAME('col' + CAST(ROW_NUMBER() OVER (PARTITION BY TeamChain ORDER BY TeamChain) AS VARCHAR))
            FROM TeamHierarchy
            FOR XML PATH(''), TYPE
            ).value('.', 'NVARCHAR(MAX)') 
        ,1,1,'');

SET @query = N'
WITH TeamHierarchy AS (
    SELECT EMP_NO, EMP_NAME, TEAM_LEADER, CAST(EMP_NAME AS VARCHAR(MAX)) AS TeamChain
    FROM TEAM_HRE
    WHERE TEAM_LEADER IS NULL
    
    UNION ALL
    
    SELECT t.EMP_NO, t.EMP_NAME, t.TEAM_LEADER, t.EMP_NAME + '', '' + th.TeamChain
    FROM TEAM_HRE t
    INNER JOIN TeamHierarchy th ON t.TEAM_LEADER = th.EMP_NAME
)

SELECT EMP_NO, EMP_NAME, TEAM_LEADER, ' + @cols + '
FROM ( 
    SELECT EMP_NO, EMP_NAME, TEAM_LEADER, TeamChain,
           ''col'' + CAST(ROW_NUMBER() OVER (PARTITION BY TeamChain ORDER BY TeamChain) AS VARCHAR) AS Col, 
           Split.value(''.'', ''VARCHAR(MAX)'') AS value
    FROM TeamHierarchy AS sd 
    CROSS APPLY STRING_SPLIT(REPLACE(TeamChain, '', ''), '','') AS Split 
) AS tbl
PIVOT (
    MAX(Value) FOR Col IN (' + @cols + ')
) AS Pvt
ORDER BY EMP_NO;';

EXEC sp_executesql @query;


CREATE PROCEDURE GetTeamHierarchy
AS
BEGIN
    SET NOCOUNT ON;

    WITH TeamHierarchy AS (
        SELECT EMP_NO, EMP_NAME, TEAM_LEADER, CAST(EMP_NAME AS VARCHAR(MAX)) AS TeamChain
        FROM TEAM_HRE
        WHERE TEAM_LEADER IS NULL

        UNION ALL

        SELECT t.EMP_NO, t.EMP_NAME, t.TEAM_LEADER, t.EMP_NAME + ',' + th.TeamChain
        FROM TEAM_HRE t
        INNER JOIN TeamHierarchy th ON t.TEAM_LEADER = th.EMP_NAME
    )

    SELECT EMP_NO, EMP_NAME ,TEAM_LEADER,
           ISNULL([col1],'NULL') AS [col1], 
           ISNULL([col2],'NULL') AS [col2], 
           ISNULL([col3],'NULL') AS [col3], 
           ISNULL([col4],'NULL') AS [col4],
           ISNULL([col5],'NULL') AS [col5],
           ISNULL([col6],'NULL') AS [col6]

    FROM ( 
        SELECT EMP_NO, EMP_NAME, TEAM_LEADER, TeamChain,
               'col'+ CAST(ROW_NUMBER() OVER (PARTITION BY TeamChain ORDER BY TeamChain) AS VARCHAR) AS Col, 
               value 
        FROM TeamHierarchy AS sd 
        CROSS APPLY STRING_SPLIT(TeamChain,',') AS Split 
    ) AS tbl
    PIVOT (
        MAX(Value) FOR Col IN ([col1],[col2],[col3],[col4],[col5],[col6])
    ) AS Pvt
    ORDER BY EMP_NO;
END;

EXEC GetTeamHierarchy;





DECLARE @StartDate DATE = '2024-01-01';
DECLARE @EndDate DATE = '2024-12-31';

WITH MonthDates AS (
    SELECT 
        DATEADD(MONTH, DATEDIFF(MONTH, 0, @StartDate), 0) AS StartOfMonth,
        EOMONTH(DATEADD(MONTH, DATEDIFF(MONTH, 0, @StartDate), 0)) AS EndOfMonth

    UNION ALL

    SELECT 
        DATEADD(MONTH, 1, StartOfMonth),
        EOMONTH(DATEADD(MONTH, 1, StartOfMonth))
    FROM MonthDates
    WHERE StartOfMonth < @EndDate
)

SELECT 
    StartOfMonth AS 'Start Date',
    EndOfMonth AS 'End Date'
FROM MonthDates
OPTION (MAXRECURSION 0);



WITH  EmployeeHierarchy AS (
    SELECT EMP_NO, EMP_NAME, TEAM_LEADER, 1 AS depth
    FROM TEAM_HRE
    WHERE TEAM_LEADER IS NULL -- Starting with the top-level manager (CEO)
    UNION ALL
    SELECT e.EMP_NO, e.EMP_NAME, e.TEAM_LEADER, eh.depth + 1
    FROM TEAM_HRE e
    JOIN EmployeeHierarchy eh ON e.TEAM_LEADER = eh.EMP_NAME
)
SELECT *
into #TEMP 
FROM EmployeeHierarchy;
 
select * from #TEMP;
--------------------------------------------------------------------------------------------------------------------
DECLARE @cols NVARCHAR(MAX),
        @query NVARCHAR(MAX);
 
SET @cols = N'';
 
-- Get the distinct column names dynamically
SELECT @cols += QUOTENAME('col' + CAST(depth AS VARCHAR)) + ','
FROM (SELECT DISTINCT depth FROM #TEMP) AS Subquery;
 
-- Remove the trailing comma from @cols
SET @cols = LEFT(@cols, LEN(@cols) - 1);
 
PRINT @cols
 
SET @query = 
    N'WITH TeamHierarchy AS (
        SELECT EMP_NO, EMP_NAME, TEAM_LEADER, CAST(EMP_NAME AS VARCHAR(MAX)) AS TeamChain
        FROM TEAM_HRE
        WHERE TEAM_LEADER IS NULL
        UNION ALL
        SELECT t.EMP_NO, t.EMP_NAME, t.TEAM_LEADER, t.EMP_NAME + '','' + th.TeamChain
        FROM TEAM_HRE t
        INNER JOIN TeamHierarchy th ON t.TEAM_LEADER = th.EMP_NAME
    )
    SELECT EMP_NO, EMP_NAME ,TEAM_LEADER, ' + @cols + '
    FROM (
        SELECT EMP_NO, EMP_NAME, TEAM_LEADER, TeamChain,
               ''col''+ CAST(ROW_NUMBER()OVER(PARTITION BY TeamChain ORDER BY TeamChain) AS VARCHAR) AS Col, 
               value 
        FROM TeamHierarchy AS sd 
        CROSS APPLY String_split(TeamChain, '','') AS Split 
    ) AS tbl
    PIVOT (
        MAX(Value) FOR Col IN (' + @cols + ')
    ) AS Pvt
    ORDER BY EMP_NO;';
 
EXEC sp_executesql @query;