USE ARYANDB
drop table split_data

-- Create table
CREATE TABLE split_data (
    incoming_data VARCHAR(20),
    new_column1 VARCHAR(20),
    new_column2 VARCHAR(20),
    new_column3 VARCHAR(20) ,
    new_column4 VARCHAR(20) ,
    new_column5 VARCHAR(20)
);

-- Insert data into split_data table
INSERT INTO split_data (incoming_data) VALUES 
('a1,b1,c1'),
('a2,b2'),
('a3,b3,c3,d3'),
('a4,b4,c4,d4,e4'),
('c5,d5,e5');

INSERT INTO split_data (new_column1, new_column2, new_column3 , new_column4 , new_column5)
SELECT 
    SUBSTRING_INDEX(incoming_data, ',', 1) AS col1,
    SUBSTRING_INDEX(SUBSTRING_INDEX(incoming_data, ',', 2), ',', -1) AS col2,
    SUBSTRING_INDEX(SUBSTRING_INDEX(incoming_data, ',', 3), ',', -1) AS col3,
	SUBSTRING_INDEX(SUBSTRING_INDEX(incoming_data, ',', 4), ',', -1) AS col4,
    SUBSTRING_INDEX(SUBSTRING_INDEX(incoming_data, ',', 5), ',', -1) AS col5
FROM  split_data 

SELECT * FROM split_data;



-- Split data by comma and insert into new column
UPDATE split_data
SET new_column1 = SUBSTR(incoming_data, 1, 2);

UPDATE split_data
SET new_column2 = SUBSTRING(incoming_data, 4 , 5);

UPDATE split_data
SET new_column3 = SUBSTR(incoming_data, 7, 8);

UPDATE split_data
SET new_column4 = SUBSTR(incoming_data, 10, 11);

UPDATE split_data
SET new_column5 = SUBSTR(incoming_data, 13, 14);
SELECT * FROM split_data;



UPDATE split_data
SET new_column1 = SUBSTRING_INDEX(SUBSTRING_INDEX(incoming_data, ',', 1), ',', -1),
    new_column2 = SUBSTRING_INDEX(SUBSTRING_INDEX(incoming_data, ',', 2), ',', -1),
    new_column3 = SUBSTRING_INDEX(SUBSTRING_INDEX(incoming_data, ',', 3), ',', -1),
    new_column4 = SUBSTRING_INDEX(SUBSTRING_INDEX(incoming_data, ',', 4), ',', -1),
    new_column5 = SUBSTRING_INDEX(SUBSTRING_INDEX(incoming_data, ',', 5), ',', -1);

-- Display the result
SELECT * FROM split_data;

SELECT incoming_data,
    LEFT(incoming_data, locate(',', incoming_data)-1) AS 'new_column_1' , 
    RIGHT(incoming_data, locate(',', incoming_data)-1) AS 'new_column_2'
FROM split_data;
/*
select substring_index ("ABC| BGF| TYH ",'|',1) AS STRING;

select substring_index ("ABC
BGF
TYH ",'\n',2) AS STRING
*/

UPDATE split_data SET
        `new_column1` = IF ( 
            LOCATE(',', incoming_data) >0,
            SUBSTRING(incoming_data, 1,LOCATE(',', incoming_data)-1),
            new_column1
    ),
        `new_column2` = IF( 
            LOCATE(',', incoming_data) > 0,
            SUBSTRING(incoming_data,LOCATE(',', incoming_data)+1),
            ''); 
    SELECT * FROM split_data;

    UPDATE split_data SET
        `new_column3` = IF (
            LOCATE(',', new_column2) >0, 
            SUBSTRING(new_column2, LOCATE(',', new_column2)+1), '');
    SELECT * FROM split_data;

    UPDATE split_data SET
        `new_column4` = IF (
            LOCATE(',', new_column3) >0, 
            SUBSTRING(new_column3, LOCATE(',', new_column3)+1), '');
	SELECT * FROM split_data;

    UPDATE split_data SET
        `new_column5` = IF (
            LOCATE(',', new_column4) >0, 
            SUBSTRING(new_column4, LOCATE(',', new_column4)+1), '');

SELECT * FROM split_data ORDER BY incoming_data;





SELECT * FROM split_data WHERE split_data.incoming_data IN (splitStringFunction(commaSeparatedData, ','));

SELECT * FROM split_data WHERE FIND_IN_SET(split_data.incoming_data, commaSeparatedData);

SELECT * FROM split_data WHERE find_in_set(split_data.incoming_data,commaSeparatedData) > 0;
Error Code: 1054. Unknown column 'commaSeparatedData' in 'where clause'

SELECT incoming_data, value
FROM  split_data
CROSS APPLY STRING_SPLIT(incoming_data, ',')

INSERT INTO split_data (new_column1, new_column2, new_column3 , new_column4 , new_column5)
SELECT 
    SUBSTRING_INDEX(incoming_data, ',', 1) AS col1,
    SUBSTRING_INDEX(SUBSTRING_INDEX(incoming_data, ',', 2), ',', -1) AS col2,
    SUBSTRING_INDEX(SUBSTRING_INDEX(incoming_data, ',', 3), ',', -1) AS col3,
	SUBSTRING_INDEX(SUBSTRING_INDEX(incoming_data, ',', 4), ',', -1) AS col4,
    SUBSTRING_INDEX(SUBSTRING_INDEX(incoming_data, ',', 5), ',', -1) AS col5
FROM  split_data 
SELECT * FROM split_data
CROSS APPLY STRING_SPLIT(t.col1, ',')) AS s     
    
CREATE TABLE split_result (
    incoming_data VARCHAR(255),
    col1 VARCHAR(255),
    col2 VARCHAR(255),
    col3 VARCHAR(255),
    col4 VARCHAR(255),
    col5 VARCHAR(255)
);

INSERT INTO split_data (incoming_data, col1, col2, col3, col4, col5)
SELECT 
    incoming_data,
    MAX(CASE WHEN Column1 = 'col1' THEN value ELSE '' END) AS col1,
    MAX(CASE WHEN Column1 = 'col2' THEN value ELSE '' END) AS col2,
    MAX(CASE WHEN Column1 = 'col3' THEN value ELSE '' END) AS col3,
    MAX(CASE WHEN Column1 = 'col4' THEN value ELSE '' END) AS col4,
    MAX(CASE WHEN Column1 = 'col5' THEN value ELSE '' END) AS col5
FROM (
    SELECT incoming_data,
           CONCAT('col', ROW_NUMBER() OVER (PARTITION BY incoming_data ORDER BY incoming_data)) AS Column1,
           value 
    FROM split_data AS sd 
    CROSS JOIN STRING_SPLIT(incoming_data, ',')
) AS tbl
GROUP BY incoming_data, Column1;

SELECT * FROM split_result;



SELECT 
    incoming_data,
    MAX(CASE WHEN Column1 = 'col1' THEN value ELSE '' END) AS col1,
    MAX(CASE WHEN Column1 = 'col2' THEN value ELSE '' END) AS col2,
    MAX(CASE WHEN Column1 = 'col3' THEN value ELSE '' END) AS col3,
    MAX(CASE WHEN Column1 = 'col4' THEN value ELSE '' END) AS col4,
    MAX(CASE WHEN Column1 = 'col5' THEN value ELSE '' END) AS col5
FROM (
    SELECT incoming_data,
           CONCAT('incoming_data', ROW_NUMBER() OVER (PARTITION BY incoming_data ORDER BY incoming_data)) AS Column1,
           value 
    FROM split_data AS sd 
    CROSS JOIN STRING_SPLIT(incoming_data, ',')
) AS tbl
GROUP BY incoming_data, Column1;



SELECT incoming_data,
ISNULL([col1],'') AS [col1], 
ISNULL([col2],'') AS [col2], 
ISNULL([col3],'') AS [col3], 
ISNULL([col4],'') AS [col4],
ISNULL([col5],'') AS [col5]
FROM ( 
 SELECT incoming_data, 
 'col'+ CAST(ROW_NUMBER()OVER(PARTITION BY incoming_data ORDER BY incoming_data) AS VARCHAR) AS Column1, 
 Split.value 
 FROM split_data AS sd 
 CROSS APPLY String_split(incoming_data,',') AS Split 
 ) AS tbl
Pivot (Max(Value) FOR Column1 IN ([col1],[col2],[col3],[col4],[col5])
) AS Pvt


SELECT incoming_data , values
FROM split_data
    CROSS APPLY STRING_SPLIT(incoming_data, ',') AS split;

SELECT t3.Value,[1] as column_1,[2] as column_2,[3] as column_3,[4] as column_4,[5] as column_5
FROM split_data as t1
CROSS APPLY (String,',') as t2
PIVOT(MAX(Item) FOR ItemNumber IN ([1],[2],[3],[4],[5])) as t3

