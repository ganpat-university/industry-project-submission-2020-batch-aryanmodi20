SHOW tableS

SELECT * FROM countries;
SELECT * FROM departments;
SELECT * FROM locations;
SELECT * from employees;

`employees`.`EMPLOYEE_ID`, `employees`.`FIRST_NAME`, `employees`.`LAST_NAME`, `employees`.`EMAIL`, `employees`.`PHONE_NUMBER`, `employees`.`HIRE_DATE`, `employees`.`JOB_ID`, `employees`.`SALARY`, `employees`.`COMMISSION_PCT`, `employees`.`MANAGER_ID`, `employees`.`DEPARTMENT_ID`

-- 1. Find all employees who work in the same department as employee 90.
SELECT EMPLOYEE_ID , FIRST_NAME FROM employees WHERE
(SELECT DEPARTMENT_ID FROM employees WHERE DEPARTMENT_ID = 90 GROUP BY DEPARTMENT_ID); 

-- 2. List all employees whose salary is higher than the average salary in their department.
SELECT EMPLOYEE_ID , FIRST_NAME , SALARY FROM employees WHERE
SALARY > (SELECT AVG(SALARY) FROM employees)

-- 3. Show me the names and emails of all employees who report to manager 121 , 100 , 205.
SELECT FIRST_NAME , EMAIL FROM employees WHERE
MANAGER_ID IN (SELECT MANAGER_ID FROM employees WHERE MANAGER_ID = 100 OR MANAGER_ID = 121 OR MANAGER_ID = 205)

-- 4. Find the JOB id ST_CLERK who have the reports to manager id 120 , 124.
SELECT EMPLOYEE_ID, FIRST_NAME, JOB_ID , MANAGER_ID
FROM employees e
WHERE EXISTS (
    SELECT 1
    FROM employees m
    WHERE m.MANAGER_ID = e.MANAGER_ID
    AND m.MANAGER_ID IN (120, 124)
)
AND e.JOB_ID = 'ST_CLERK';


SELECT FIRST_NAME , JOB_ID FROM employees WHERE
MANAGER_ID IN (SELECT MANAGER_ID FROM employees WHERE MANAGER_ID = 120 OR MANAGER_ID = 124)
AND JOB_ID = 'ST_CLERK';

-- 5. Which department has the highest average commission rate?
SELECT d.department_name, sum(e.commission_pct) AS avg_commission_rate
FROM employees e
INNER JOIN departments d ON e.department_id = d.department_id
GROUP BY d.department_name
ORDER BY avg_commission_rate DESC;





-----------------------------------------------------------------
create table recomendation_sys(id int, verticals varchar(20),
service_line varchar(20), customer varchar(20),
product varchar(20));
 
insert into recomendation_sys values
(1, 'clothing', 'summer', 'prada', 'shirt'),
(2, 'clothing', 'summer', 'zara', 'pants'),
(3, 'clothing', 'summer', 'zara', 'shirt'),
(4, 'clothing', 'summer', 'zara', 'jeans'),
(5, 'clothing', 'summer', 'gucci', 'jeans'),
(6, 'clothing', 'summer', 'gucci', 'caps'),
(7, 'clothing', 'summer', 'gucci', 'pants'),
(8, 'clothing', 'summer', 'gucci', 'shades'),
(9, 'clothing', 'summer', 'gucci', 'jeans'),
(10, 'footwear', 'rainy', 'nike', 'flipflops'),
(11, 'footwear', 'rainy', 'nike', 'sandals'),
(12, 'footwear', 'rainy', 'nike', 'slipers'),
(13, 'footwear', 'rainy', 'adidas', 'flipflops'),
(14, 'footwear', 'rainy', 'adidas', 'boots'),
(15, 'footwear', 'rainy', 'adidas', 'sneakers'),
(16,'footwear', 'rainy', 'puma', 'sneakers'),
(17, 'clothing', 'winter', 'h&m', 'jacket'),
(18, 'clothing', 'winter', 'h&m', 'scarfs'),
(19, 'clothing', 'winter', 'h&m', 'hoodie'),
(20, 'clothing', 'winter', 'armani', 'jacket'),
(21, 'clothing', 'winter', 'armani', 'coats'),
(22, 'clothing', 'winter', 'armani', 'muffler'),
(23, 'clothing', 'winter', 'lv', 'coats'),
(24, 'sports', 'football', 'underarmour', 'studds'),
(25, 'sports', 'football', 'underarmour', 'jersys'),
(26, 'sports', 'football', 'underarmour', 'socks'),
(27, 'sports', 'football', 'newbalance', 'studds'),
(28, 'sports', 'football', 'newbalance', 'jersys'),
(29, 'sports', 'football', 'newbalance', 'shorts'),
(30, 'sports', 'football', 'newbalance', 'inner'),
(31, 'sports', 'football', 'skechers', 'shorts'),
(32, 'sports', 'football', 'skechers', 'shorts'),
(33, 'clothing', 'winter', 'lv', 'scarfs');
 
select * from recomendation_sys;

SELECT * FROM recomendation_sys where customer = 'zara';
SELECT * FROM recomendation_sys where customer = 'gucci';

-- DROP PROCEDURE recommend_product
CREATE PROCEDURE recommend_product(
  IN customer VARCHAR(20)
)
AS
BEGIN
  /* Find the vertical and service line for the given customer */
  DECLARE vertical VARCHAR(20);
  DECLARE service_line VARCHAR(20);
  
  SELECT verticals, service_line INTO vertical, service_line
  FROM recomendation_sys
  WHERE customer = customer;

  /* Check if customer and vertical/service line exist */
  IF (vertical IS NULL OR service_line IS NULL) THEN
    SELECT 'Customer or vertical/service line not found' AS message;
    RETURN;
  END IF;

  /* Find similar brands based on vertical and service line */
  SELECT DISTINCT product
  FROM recomendation_sys
  WHERE verticals = vertical AND service_line = service_line
    AND customer != customer;

  /* Choose product randomly from similar brands */
  SELECT product
  FROM (
    SELECT product
    FROM recomendation_sys
    WHERE verticals = vertical AND service_line = service_line
      AND customer != customer
    ORDER BY RAND()
  ) AS similar_products
  LIMIT 1;
END;

DELIMITER //

CREATE PROCEDURE RecommendProductsByCustomer(
    IN input_customer VARCHAR(20)
)
BEGIN
    SELECT product
    FROM recomendation_sys
    WHERE customer = input_customer;
END //

DELIMITER ;



Error Code: 1064. You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IN input_service_line VARCHAR(20), IN input_verticals VARCHAR(20)) BEGIN     SEL' at line 1



