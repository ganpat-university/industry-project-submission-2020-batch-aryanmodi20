CREATE TABLE PMS_HOLIDAY(
	HOLIDAYS DATE
);
 
INSERT INTO PMS_HOLIDAY
VALUES('2024-01-01'),('2024-01-26'),('2024-03-25'),('2024-04-09')

SELECT * FROM PMS_HOLIDAY
-- DROP TABLE LEAVE
CREATE TABLE LEAVE (
	NAME NVARCHAR(50),
	STARTDATE DATE,
	ENDDATE DATE
);
 
INSERT INTO LEAVE
VALUES('ABC', '2024-01-15','2024-01-15'),('pqr','2024-01-31','2024-02-02'),('XYZ','2024-01-26','2024-01-29');

SELECT * FROM LEAVE;
SELECT * FROM PMS_HOLIDAY



WITH CTE_Calendar AS (
    SELECT
        DATEADD(DAY, number, '2024-01-01') AS CalendarDate
    FROM master.dbo.spt_values
    WHERE type = 'P' AND number <= DATEDIFF(DAY, '2024-01-01', '2024-12-31')
),


WITH CTE_WorkingDays AS (
SELECT
    HOLIDAYS,
    CASE
        WHEN DATEPART(WEEKDAY, HOLIDAYS) NOT IN (1, 7)  -- Exclude Sundays (1) and Saturdays (7)
            AND HOLIDAYS NOT IN (SELECT HOLIDAYS FROM PMS_HOLIDAY) -- Exclude holidays
        THEN 1  -- 1 for working day, 0 for non-working day
        ELSE 0
    END AS WorkingDay
FROM PMS_HOLIDAY
)
SELECT
    FORMAT(STARTDATE, 'yyyy-MM') AS Month,
    NAME,
    DATEDIFF(DAY, STARTDATE, ENDDATE) + 1 AS LeaveCount
FROM Leave
--GROUP BY FORMAT(STARTDATE, 'yyyy-MM'), NAME
--ORDER BY Month, NAME;


---------------------------------------------------------------------
SELECT 
    a.NAME,
    SUM(
        CASE 
            WHEN DATEPART(WEEKDAY, a.LEAVE_DAYS) IN (1, 7) OR h.HOLIDAYS IS NOT NULL THEN 0 
            ELSE a.LEAVE_DAYS
        END
    ) AS LEAVE_cnt
FROM (
    SELECT 
        NAME,
        DATEDIFF(DAY, STARTDATE, ENDDATE) + 1 AS LEAVE_DAYS
    FROM 
        LEAVE
) AS a
LEFT JOIN 
    PMS_HOLIDAY h ON a.LEAVE_DAYS = h.HOLIDAYS
GROUP BY 
    a.NAME;


-----------------------------------------------

CREATE PROCEDURE CalculateLeaveCount
AS
BEGIN
    SELECT 
        a.NAME,
        SUM(
            CASE 
                WHEN DATEPART(WEEKDAY, a.LEAVE_DAYS) IN (1, 7) OR h.HOLIDAYS IS NOT NULL THEN 0 
                ELSE a.LEAVE_DAYS
            END
        ) AS LEAVE_cnt
    FROM (
        SELECT 
            NAME,
            DATEDIFF(DAY, STARTDATE, ENDDATE) + 1 AS LEAVE_DAYS
        FROM 
            LEAVE
    ) AS a
    LEFT JOIN 
        PMS_HOLIDAY h ON a.LEAVE_DAYS = h.HOLIDAYS
    GROUP BY 
        a.NAME;
END;

-----------------------------------------------
EXEC CalculateLeaveCount;

