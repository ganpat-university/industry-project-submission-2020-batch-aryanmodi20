
CREATE TABLE type2_source(
	empid int,
	emp_name VARCHAR(10),
	company_name VARCHAR(10),
	join_date date
);

INSERT INTO type2_source VALUES
(1 , 'Sahana' , 'IBM' , '2024-01-22'),
(2 , 'Aryan' , 'IBM' , '2021-06-11'),
(3 , 'Faisal' , 'Microsoft' , '2023-09-11');

SELECT * FROM type2_source

CREATE TABLE type2_target(
	empid int,
	emp_name VARCHAR(10),
	company_name VARCHAR(10),
	join_date date ,
	FLAG VARCHAR(2)
);

INSERT INTO type2_target VALUES
(1 , 'Sahana' , NULL , '2022-02-22' , 'Y'),
(2 , 'Aryan' , 'IBM' , NULL , 'Y'),
(3 , 'Faisal' , 'IBM' , '2022-09-11', 'Y');

SELECT * FROM type2_target


SELECT * FROM type2_source
SELECT * FROM type2_target

MERGE type2_target AS target
USING type2_source AS source
on target.empid = source.empid
WHEN MATCHED AND FLAG ='Y'
	THEN UPDATE
		SET FLAG ='N';

INSERT INTO type2_target(type2_target.empid ,type2_target.emp_name,type2_target.company_name,type2_target.Join_date ,FLAG)
SELECT type2_source.empid,type2_source.emp_name,type2_source.company_name,type2_source.join_date , 'Y' FROM type2_source

SELECT * FROM type2_target


----------------------------------------------------
-- TYPE 3

CREATE TABLE type3_source(
	empid int,
	emp_name VARCHAR(10),
	company_name VARCHAR(10),
	join_date date
);
truncate table type3_source
INSERT INTO type3_source VALUES
(1 , 'Shana' , 'IBM' , '2024-10-22'),
(2 , 'An' , 'IBM' , '2024-10-11'),
(3 , 'Fai' , 'Microsoft' , '2024-10-11');

INSERT INTO type3_source VALUES
(4 , 'Edvin' , 'IBM' , '2024-01-22')

DELETE FROM type3_source WHERE empid = 1;


SELECT * FROM type3_source
ALTER TABLE type3_target
ADD  mody_date date;

CREATE TABLE type3_target(
	empid int,
	emp_name VARCHAR(10),
	company_name VARCHAR(15),
	company_pre VARCHAR(15),
	join_date date , 
	join_date_pre date
);

INSERT INTO type3_target VALUES
(1 , 'Sahana' , 'abc' , NULL , '2022-02-22' , NULL , NULL),
(2 , 'Aryan' , 'VERACITIZ' , NULL , '2022-04-11', NULL , NULL),
(3 , 'Faisal' , 'IBM' , NULL , '2023-02-10' , NULL , NULL );

SELECT * FROM type3_target

SELECT * FROM type3_source
SELECT * FROM type3_target


MERGE type3_target as TARGET
USING type3_source as SOURCE
ON SOURCE.empid = TARGET.empid
WHEN MATCHED
	THEN UPDATE
	SET TARGET.company_name = SOURCE.company_name ,
		TARGET.join_date = SOURCE.join_date ,
		TARGET.company_pre = TARGET.company_name ,
		TARGET.join_date_pre = TARGET.join_date ,
		TARGET.mody_date = GETDATE()
WHEN NOT MATCHED BY TARGET
	THEN INSERT(empid,emp_name,company_name, company_pre ,join_date, join_date_pre , mody_date)
	VALUES (SOURCE.empid,SOURCE.emp_name,SOURCE.company_name, NULL ,SOURCE.join_date , NULL , GETDATE())
WHEN NOT MATCHED BY SOURCE
	THEN DELETE;

SELECT * FROM type3_target

update type3_target set mody_date ='2023-08-07' 