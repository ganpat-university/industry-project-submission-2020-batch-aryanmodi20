-- DROP TABLE lg_num
CREATE TABLE lg_num (
num BIGINT
);

INSERT INTO lg_num VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(12),
(11),
(10);

WITH NumberedRows AS (
SELECT NUM,RW,RW%7 AS RN FROM(
SELECT num,
    ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS  RW
  FROM lg_num
  ) A
)
SELECT
  CASE
    WHEN RN = 1 THEN num
    WHEN RN = 2 THEN CONCAT(num, num)
    WHEN RN = 3 THEN CONCAT(num, num, num)
	WHEN RN = 4 THEN CONCAT(num, num, num,num)
    WHEN RN = 5 THEN CONCAT(num, num, num,num,num)
    WHEN RN = 6 THEN CONCAT(num, num, num,num,num,num)
    WHEN RN = 0 THEN CONCAT(num, num, num,num,num,num,num)
  END AS pattern
FROM
  NumberedRows



-- Drop PROCEDURE GeneratePattern
CREATE PROCEDURE GeneratePattern @input INT
AS
BEGIN
    DECLARE @DynamicSQL NVARCHAR(MAX)

    SET @DynamicSQL = '
        DECLARE @input INT;
        SET @input = ' + CAST(@input AS NVARCHAR(10)) + ';

        WITH NumberedRows AS (
            SELECT
                num,
                ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS RW
            FROM
                lg_num
        )
        SELECT
            ' +
            CASE
				WHEN @input = 6 THEN
                    '
                    CASE
                        WHEN RW % @input = 1 THEN num
                        WHEN RW % @input = 2 THEN CONCAT(num, num)
                        WHEN RW % @input = 3 THEN CONCAT(num, num, num)
                        WHEN RW % @input = 4 THEN CONCAT(num, num, num,num)
                        WHEN RW % @input = 5 THEN CONCAT(num, num, num,num,num)
                        WHEN RW % @input = 0 THEN CONCAT(num, num, num,num,num,num)
                    END
                    '
				WHEN @input = 5 THEN
                    '
                    CASE
                        WHEN RW % @input = 1 THEN num
                        WHEN RW % @input = 2 THEN CONCAT(num, num)
                        WHEN RW % @input = 3 THEN CONCAT(num, num, num)
                        WHEN RW % @input = 4 THEN CONCAT(num, num, num,num)
                        WHEN RW % @input = 0 THEN CONCAT(num, num, num,num,num)
                    END
                    '
				WHEN @input = 4 THEN
                    '
                    CASE
                        WHEN RW % @input = 1 THEN num
                        WHEN RW % @input = 2 THEN CONCAT(num, num)
                        WHEN RW % @input = 3 THEN CONCAT(num, num, num)
                        WHEN RW % @input = 0 THEN CONCAT(num, num, num,num)

                    END
                    '
                WHEN @input = 3 THEN
                    '
                    CASE
                        WHEN RW % @input = 1 THEN num
                        WHEN RW % @input = 2 THEN CONCAT(num, num)
                        WHEN RW % @input = 0 THEN CONCAT(num, num, num)
                    END
                    '
                WHEN @input = 2 THEN
                    '
                    CASE
                        WHEN RW % @input = 1 THEN num
                        WHEN RW % @input = 0 THEN CONCAT(num, num)
                    END
                    '
            END + ' AS pattern
        FROM
            NumberedRows
    '

    EXEC sp_executesql @DynamicSQL
END

EXEC GeneratePattern @input = 4;


CREATE PROCEDURE GeneratePattern @input INT
AS
BEGIN
    DECLARE @DynamicSQL NVARCHAR(MAX)
    DECLARE @Counter INT = 1

    SET @DynamicSQL = '
        DECLARE @input INT;
        SET @input = ' + CAST(@input AS NVARCHAR(10)) + ';

        WITH NumberedRows AS (
            SELECT
                num,
                ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS RW
            FROM
                lg_num
        )
        SELECT
            CASE
    '

    WHILE @Counter <= @input
    BEGIN
        SET @DynamicSQL = @DynamicSQL +
            'WHEN RW % @input = ' + CAST(@Counter AS NVARCHAR(10)) + ' THEN ' +
            CASE 
                WHEN @Counter = 1 THEN 'num'
                WHEN @Counter = 2 THEN 'CONCAT(num, num)'
                WHEN @Counter = 3 THEN 'CONCAT(num, num,num)'
                -- Add more cases as needed
                ELSE '... default case ...'
            END

        SET @Counter = @Counter + 1
    END

    SET @DynamicSQL = @DynamicSQL + '
        END AS pattern
        FROM
            NumberedRows
    '

    EXEC sp_executesql @DynamicSQL, N'@input INT', @input
END

EXEC GeneratePattern @input = 2;




-- DROP PROCEDURE GeneratePattern
CREATE PROCEDURE GeneratePattern @input INT
AS
BEGIN
    DECLARE @DynamicSQL NVARCHAR(MAX)

    SET @DynamicSQL = '
        WITH NumberedRows AS (
            SELECT num,
                ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS RW
            FROM lg_num
        )
        SELECT
            CASE
                WHEN RW % ' + CAST(@input AS NVARCHAR(10)) + ' = 1 THEN num
                WHEN RW % ' + CAST(@input AS NVARCHAR(10)) + ' = 2 THEN CONCAT(num, num)
                WHEN RW % ' + CAST(@input AS NVARCHAR(10)) + ' = 3 THEN CONCAT(num, num, num)
                WHEN RW % ' + CAST(@input AS NVARCHAR(10)) + ' = 4 THEN CONCAT(num, num, num,num)
                WHEN RW % ' + CAST(@input AS NVARCHAR(10)) + ' = 5 THEN CONCAT(num, num, num,num,num)
                WHEN RW % ' + CAST(@input AS NVARCHAR(10)) + ' = 6 THEN CONCAT(num, num, num,num,num,num,num)
                WHEN RW % ' + CAST(@input AS NVARCHAR(10)) + ' = 7 THEN CONCAT(num, num, num,num,num,num,num,num)
                WHEN RW % ' + CAST(@input AS NVARCHAR(10)) + ' = 8 THEN CONCAT(num, num, num,num,num,num,num,num,num)
                WHEN RW % ' + CAST(@input AS NVARCHAR(10)) + ' = 9 THEN CONCAT(num, num, num,num,num,num, num,num,num,num)
                WHEN RW % ' + CAST(@input AS NVARCHAR(10)) + ' = 0 THEN CONCAT(' + REPLICATE('num, ', @input - 1) + 'num)
            END AS pattern
        FROM
            NumberedRows
    '

    EXEC sp_executesql @DynamicSQL
END


EXEC GeneratePattern @input = 8;
---------------------------------------


SELECT 
  CASE WHEN RN = 0 then REPLICATE(num, 4) else REPLICATE(num, RN)
  END
FROM (SELECT NUM,RW,RW % 4 AS RN 
  FROM (
    SELECT num, ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS RW FROM lg_num
  ) A
) B;




