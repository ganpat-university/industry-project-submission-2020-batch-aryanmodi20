	DROP TABLE bank
truncate table bank

CREATE TABLE bank(
	Account_number int NOT NULL IDENTITY(1001,1),
	Name VARCHAR(20) ,
	DOB DATE ,
	Psw VARCHAR(10) ,
	CNF_Psw VARCHAR(10) ,
	Balance BIGINT ,
	CONSTRAINT CK_PasswordMatch CHECK (CNF_Psw = Psw)
);

INSERT INTO bank (Name, DOB , Psw , CNF_Psw , Balance)
VALUES ('ARYAN', '2003-05-27' , 'abc@' , 'abc@' , 5000) ,
       ('EDVIN', '1999-02-	27' , 'abc1' , 'abc1' , 100),
	   ('APARNA', '1997-11-27' , 'abc2' , 'abc2' , 1000),
       ('DIXIT', '2000-01-27' , 'abc3' , 'abc3' , 7000);


INSERT INTO bank (Name, DOB , Psw , CNF_Psw , Balance)
VALUES ('EDVIN', '1999-02-12' , 'abc@' , 'abc' , 5000);

SELECT Account_number , Name, DOB , Psw , Balance FROM bank


-------------------------------------------------
DROP PROCEDURE ViewTransaction

CREATE PROCEDURE ViewTransaction
    @AccountNumber INT,
    @EnteredPassword VARCHAR(10),
    @TransactionType VARCHAR(10)
AS
BEGIN
    DECLARE @CurrentBalance DECIMAL(18, 2);
    DECLARE @StoredPassword VARCHAR(50);

    SELECT @CurrentBalance = Balance, @StoredPassword = Psw
    FROM bank
    WHERE Account_number = @AccountNumber;

    IF @EnteredPassword = @StoredPassword
	BEGIN
		IF @TransactionType = 'View'
		BEGIN
            SELECT Account_number , Name, DOB , Psw , Balance FROM bank WHERE Account_number = @AccountNumber 
        END
		ELSE
			PRINT 'Invalid transaction type.';
	END
	ELSE
    BEGIN
        PRINT 'Incorrect password.';
    END
END;
-------------------------------------------------------------------------
CREATE PROCEDURE ProcessTransaction
    @AccountNumber INT,
    @Amount DECIMAL(10, 2),
    @EnteredPassword VARCHAR(10),
    @TransactionType VARCHAR(10)
AS
BEGIN
    DECLARE @CurrentBalance DECIMAL(18, 2);
    DECLARE @StoredPassword VARCHAR(50);

    SELECT @CurrentBalance = Balance, @StoredPassword = Psw
    FROM bank
    WHERE Account_number = @AccountNumber;

    IF @EnteredPassword = @StoredPassword
    BEGIN
        IF @TransactionType = 'Credit'
        BEGIN
            UPDATE bank
            SET Balance = Balance + @Amount
            WHERE Account_number = @AccountNumber;
        END
        ELSE IF @TransactionType = 'Debit'
        BEGIN
            IF @CurrentBalance >= @Amount
            BEGIN
                UPDATE bank
                SET Balance = Balance - @Amount
                WHERE Account_number = @AccountNumber;
            END
            ELSE
            BEGIN
                PRINT 'Insufficient funds.';
            END
        END
        ELSE
        BEGIN
            PRINT 'Invalid transaction type.';
        END
    END
    ELSE
    BEGIN
        PRINT 'Incorrect password.';
    END
END;


----------------------------------------
EXEC ProcessTransaction @AccountNumber = 1001, @Amount = 500.00, @EnteredPassword = 'abc@', @TransactionType = 'Credit';

EXEC ProcessTransaction @AccountNumber = 1004, @Amount = 8000.00, @EnteredPassword = 'abc3', @TransactionType = 'Debit';

EXEC ViewTransaction @AccountNumber = 1003, @EnteredPassword = 'abc2', @TransactionType = 'View';

-----------------------------------------
SELECT Account_number , Name, DOB , Psw , Balance FROM bank


