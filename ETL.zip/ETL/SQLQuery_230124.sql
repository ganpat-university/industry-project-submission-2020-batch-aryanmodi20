CREATE TABLE date_tab (
	EMP_ID int,
	PROJECT_DATE DATE
);

INSERT INTO date_tab VALUES
(1, '2022-01-01'),
(1, '2022-01-02'),
(1, '2022-01-03'),
(1, '2022-01-06'),
(1, '2022-01-07'),
(1, '2022-01-09');

SELECT * FROM date_tab;

SELECT EMP_ID, PROJECT_DATE,
       CASE WHEN LAG(PROJECT_DATE) OVER (PARTITION BY EMP_ID ORDER BY PROJECT_DATE) = DATEADD(DAY, -1, PROJECT_DATE)
            THEN NULL			
            ELSE PROJECT_DATE
       END AS START_DT,
       CASE WHEN LAG(PROJECT_DATE) OVER (PARTITION BY EMP_ID ORDER BY PROJECT_DATE) = DATEADD(DAY, 1, PROJECT_DATE)
            THEN NULL
			WHEN LEAD(PROJECT_DATE) OVER (PARTITION BY EMP_ID ORDER BY PROJECT_DATE) = DATEADD(DAY, 2, PROJECT_DATE)
            THEN NULL
			WHEN LEAD(PROJECT_DATE) OVER (PARTITION BY EMP_ID ORDER BY PROJECT_DATE) = DATEADD(DAY, 3, PROJECT_DATE)
            THEN NULL
            ELSE LAG(PROJECT_DATE ) OVER (PARTITION BY EMP_ID ORDER BY PROJECT_DATE)
       END AS END_DT
FROM date_tab;


------------------------------------------------------------------------------------------------------------------------
select c.emp_id, c.project_date, FIRST_VALUE(c.strt_date) over (partition by c.fc order by c.project_date) , c.end_date
from(
select b.emp_id, b.project_date, b.strt_date,
sum(case when b.strt_date is null then 0 else 1 end) over (order by b.project_date) fc
, b.end_date from (
SELECT A.EMP_ID, A.PROJECT_DATE, 
	 CASE WHEN DATEDIFF(D,A.LAGG,A.PROJECT_DATE)<=1 THEN NULL ELSE A.PROJECT_DATE END AS STRT_DATE ,
	 CASE WHEN DATEDIFF(D,A.LAGG,A.PROJECT_DATE)>1 THEN DATEADD(D,1,A.LAGG) ELSE NULL END AS END_DATE FROM
(SELECT * , LAG(PROJECT_DATE) OVER (ORDER BY PROJECT_DATE) AS LAGG
FROM date_tab ) A )b )c


