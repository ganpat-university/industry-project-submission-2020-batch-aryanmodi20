CREATE TABLE countries (
  COUNTRY_ID varchar(2) NOT NULL,
  COUNTRY_NAME varchar(40) DEFAULT NULL,
  REGION_ID decimal(10,0) DEFAULT NULL,
)

INSERT INTO countries VALUES ('AR','Argentina',2),('AU','Australia',3),('BE','Belgium',1),('BR','Brazil',2),('CA','Canada',2),('CH','Switzerland',1),('CN','China',3),('DE','Germany',1),('DK','Denmark',1),('EG','Egypt',4),('FR','France',1),('HK','HongKong',3),('IL','Israel',4),('IN','India',3),('IT','Italy',1),('JP','Japan',3),('KW','Kuwait',4),('MX','Mexico',2),('NG','Nigeria',4),('NL','Netherlands',1),('SG','Singapore',3),('UK','United Kingdom',1),('US','United States of America',2),('ZM','Zambia',4),('ZW','Zimbabwe',4);

SELECT * FROM countries;

CREATE TABLE departments (
  DEPARTMENT_ID decimal(4,0) NOT NULL DEFAULT '0',
  DEPARTMENT_NAME varchar(30) NOT NULL,
  MANAGER_ID decimal(6,0) DEFAULT NULL,
  LOCATION_ID decimal(4,0) DEFAULT NULL,
)

INSERT INTO departments VALUES (10,'Administration',200,1700),(20,'Marketing',201,1800),(30,'Purchasing',114,1700),(40,'Human Resources',203,2400),(50,'Shipping',121,1500),(60,'IT',103,1400),(70,'Public Relations',204,2700),(80,'Sales',145,2500),(90,'Executive',100,1700),(100,'Finance',108,1700),(110,'Accounting',205,1700),(120,'Treasury',0,1700),(130,'Corporate Tax',0,1700),(140,'Control And Credit',0,1700),(150,'Shareholder Services',0,1700),(160,'Benefits',0,1700),(170,'Manufacturing',0,1700),(180,'Construction',0,1700),(190,'Contracting',0,1700),(200,'Operations',0,1700),(210,'IT Support',0,1700),(220,'NOC',0,1700),(230,'IT Helpdesk',0,1700),(240,'Government Sales',0,1700),(250,'Retail Sales',0,1700),(260,'Recruiting',0,1700),(270,'Payroll',0,1700);

SELECT * FROM departments;


CREATE TABLE locations (
  LOCATION_ID decimal(4,0) NOT NULL DEFAULT '0',
  STREET_ADDRESS varchar(40) DEFAULT NULL,
  POSTAL_CODE varchar(12) DEFAULT NULL,
  CITY varchar(30) NOT NULL,
  STATE_PROVINCE varchar(25) DEFAULT NULL,
  COUNTRY_ID varchar(2) DEFAULT NULL,
)

INSERT INTO locations VALUES (1000,'1297 Via Cola di Rie','989','Roma','','IT'),(1100,'93091 Calle della Testa','10934','Venice','','IT'),(1200,'2017 Shinjuku-ku','1689','Tokyo','Tokyo Prefecture','JP'),(1300,'9450 Kamiya-cho','6823','Hiroshima','','JP'),(1400,'2014 Jabberwocky Rd','26192','Southlake','Texas','US'),(1500,'2011 Interiors Blvd','99236','South San Francisco','California','US'),(1600,'2007 Zagora St','50090','South Brunswick','New Jersey','US'),(1700,'2004 Charade Rd','98199','Seattle','Washington','US'),(1800,'147 Spadina Ave','M5V 2L7','Toronto','Ontario','CA'),(1900,'6092 Boxwood St','YSW 9T2','Whitehorse','Yukon','CA'),(2000,'40-5-12 Laogianggen','190518','Beijing','','CN'),(2100,'1298 Vileparle (E)','490231','Bombay','Maharashtra','IN'),(2200,'12-98 Victoria Street','2901','Sydney','New South Wales','AU'),(2300,'198 Clementi North','540198','Singapore','','SG'),(2400,'8204 Arthur St','','London','','UK'),(2500,'\"Magdalen Centre',' The Oxford ','OX9 9ZB','Oxford','Ox'),(2600,'9702 Chester Road','9629850293','Stretford','Manchester','UK'),(2700,'Schwanthalerstr. 7031','80925','Munich','Bavaria','DE'),(2800,'Rua Frei Caneca 1360','01307-002','Sao Paulo','Sao Paulo','BR'),(2900,'20 Rue des Corps-Saints','1730','Geneva','Geneve','CH'),(3000,'Murtenstrasse 921','3095','Bern','BE','CH'),(3100,'Pieter Breughelstraat 837','3029SK','Utrecht','Utrecht','NL'),(3200,'Mariano Escobedo 9991','11932','Mexico City','\"Distrito Federal','\"');

SELECT * FROM locations;


--1. Write a query to find the addresses (location_id, street_address, city, state_province, country_name) of all the departments.
SELECT departments.DEPARTMENT_NAME ,  locations.LOCATION_ID , locations.STREET_ADDRESS , locations.CITY , locations.STATE_PROVINCE , locations.COUNTRY_ID 
FROM locations
INNER JOIN departments
ON locations.LOCATION_ID = departments.LOCATION_ID;

--2. Write a query to find the name (first_name, last name), department ID and name of all the employees
SELECT employees.FIRST_NAME , employees.LAST_NAME , departments.DEPARTMENT_ID 
FROM employees
LEFT JOIN departments
ON employees.DEPARTMENT_ID = departments.DEPARTMENT_ID;

--3. Write a query to find the name (first_name, last_name), job, department ID and name of the employees who works in India.
SELECT e.FIRST_NAME, e.LAST_NAME, e.JOB_ID, d.DEPARTMENT_ID
FROM employees e
JOIN departments d ON e.DEPARTMENT_ID = d.DEPARTMENT_ID
JOIN locations l ON d.LOCATION_ID = l.LOCATION_ID
WHERE l.COUNTRY_ID = 'IN';

--4. Write a query to find the employee id, name (last_name) along with their manager_id and name (last_name).
SELECT e.EMPLOYEE_ID , e.LAST_NAME, e.MANAGER_ID , m.LAST_NAME AS MANAGER_LNAME
FROM employees e 
JOIN employees m ON e.LAST_NAME = m.LAST_NAME;

--5. Write a query to find the name (first_name, last_name) and hire date of the employees who was hired after 'Jones'.
SELECT FIRST_NAME, LAST_NAME, HIRE_DATE
FROM employees
WHERE HIRE_DATE > (SELECT HIRE_DATE FROM employees WHERE LAST_NAME = 'Jones');

--6. Write a query to get the department name and number of employees in the department.
SELECT d.DEPARTMENT_NAME, COUNT(e.DEPARTMENT_ID) AS cnt_emp
FROM departments d
LEFT JOIN employees e ON d.DEPARTMENT_ID = e.DEPARTMENT_ID
GROUP BY DEPARTMENT_NAME;

--7. Write a query to find the employee ID, job title, number of days between ending date and starting date for all jobs in department 90.
SELECT EMPLOYEE_ID, JOB_ID, DATEDIFF(DAY, HIRE_DATE , GETDATE()) AS DAYS_BETWEEN
FROM employees
WHERE employees.DEPARTMENT_ID = 90;

--8. Write a query to display the department ID and name and first name of manager.
SELECT d.DEPARTMENT_ID , d.DEPARTMENT_NAME , m.FIRST_NAME AS MANAGER_FNAME
FROM employees m
RIGHT JOIN departments d ON d.MANAGER_ID = m.MANAGER_ID;

--9. Write a query to display the department name, manager name, and city
SELECT d.DEPARTMENT_NAME , e.FIRST_NAME , e.LAST_NAME, l.CITY
FROM employees e
JOIN departments d ON d.MANAGER_ID = e.MANAGER_ID 
JOIN locations l ON l.LOCATION_ID = d.LOCATION_ID;

--10. Write a query to display the job title and average salary of employees.
SELECT JOB_ID , AVG(SALARY) AS avg_sal FROM employees GROUP BY JOB_ID;

--11. Write a query to display job title, employee name, and the difference between salary of the employee and minimum salary for the job.
SELECT e.JOB_ID, e.FIRST_NAME , e.LAST_NAME , e.SALARY - j.MIN_SALARY AS SALARY_DIFFERENCE
FROM employees e
JOIN (SELECT JOB_ID , MIN(SALARY) AS MIN_SALARY FROM employees GROUP BY JOB_ID) j 
ON e.JOB_ID = j.JOB_ID;

--12. Write a query to display the job history that were done by any employee who is currently drawing more than 10000 of salary. 
SELECT e.FIRST_NAME ,  e.LAST_NAME AS EMPLOYEE_NAME
FROM employees e
WHERE e.SALARY > 10000;

--13. Write a query to display department name, name (first_name, last_name), hire date, salary of the manager for all managers whose experience is more than 15 years.
SELECT d.DEPARTMENT_NAME, e.FIRST_NAME , e.LAST_NAME, e.HIRE_DATE, e.SALARY
FROM employees e
JOIN departments d ON e.EMPLOYEE_ID = d.MANAGER_ID
WHERE DATEDIFF(YEAR, HIRE_DATE, GETDATE()) >= 15;
