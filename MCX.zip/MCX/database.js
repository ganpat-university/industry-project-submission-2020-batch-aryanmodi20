const express = require('express');
const sql = require('mssql');
const app = express();
const port = 3000;

const config = {
  server: 'ARYAN-MODI',
  database: 'test',
  user: 'aryan',
  password: 'aryan123', 
  options: {
    trustedConnection: true,
    trustServerCertificate: true
  }
};

app.get('/', async (req, res) => {
  try {
    const pool = await sql.connect(config);

    // Fetch table names
    const result = await pool.request().query("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'");
    const tableNames = result.recordset.map(row => row.TABLE_NAME);

    // Fetch column names for all tables
    const columnPromises = tableNames.map(async tableName => {
      const columnResult = await pool
        .request()
        .query(`SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '${tableName}'`);
      return {
        tableName,
        columnNames: columnResult.recordset.map(row => row.COLUMN_NAME)
      };
    });

    const columnsData = await Promise.all(columnPromises);

    // Log fetched table and column names
    console.log('Table Names:', tableNames);
    console.log('Column Data:', columnsData);

    // Generate HTML for table buttons
    const tableListHTML = tableNames.map(tableName => `<button draggable="true" ondragstart="drag(event)" data-column="${tableName}" onclick="fetchColumns('${tableName}')">${tableName}</button>`).join('\n');

    // Generate HTML for column names
    const columnListHTML = columnsData.map(data => `
        <div class="column-list" data-table="${data.tableName}">
            <p>Column Names for ${data.tableName}:</p>
            ${data.columnNames.map(columnName => `<button draggable="true" ondragstart="drag(event)" data-column="${columnName}">${columnName}</button>`).join('\n')}
        </div>
        `).join('\n');

    // Respond with HTML including the dynamic table and column names
    res.send(`
      <!DOCTYPE HTML>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>MCX LOOP SQL</title>
        <style>
        /* Add your global styles here */

        .top {
          display: flex;
        }

        .tab-list {
          width: 20%;
          height: 60vh;
          box-sizing: border-box;
          border: 5px solid #aaaaaa;
          overflow-y: auto;
        }

        .drop-container {
          width: 80%;
          height: 60vh;
          box-sizing: border-box;
          margin-left: 5px; /* Optional: Add margin between buttons */
          border: 5px solid #aaaaaa;
          overflow-y: auto;
        }

        .container {
          display: flex;
          width: 100%;
          height: 40vh;
          box-sizing: border-box;
        }

        .frame-container {
          flex: 1; /* Use flex property to make it flexible and take available space */
          height: 40vh;
          box-sizing: border-box;
          overflow-y: auto;
          border: 5px solid #aaaaaa;
        }

        .condition-container {
          width: 20%;
          height: 20vh;
          box-sizing: border-box;
          border: 5px solid #aaaaaa;
        }

        .iframe {
          width: 100%;
          height: 100%;
          border: 1px solid #aaaaaa;
          box-sizing: border-box;
        }

        </style>
      </head>
      <body>
        <div class="top">
          <div class="tab-list">
            <p>Table List</p>
            <input type="text" id="tableSearch" placeholder="Search Table" oninput="filterTables()">
            </br>
            </br>
            ${tableListHTML}
          </div>

          <div class="drop-container">
            <p>Search column:</p>
            <input type="text" id="columnSearch" placeholder="Search Column" oninput="filterColumns()">
            ${columnListHTML}
            </div>
        </div>

        <div class="container">
          <div class="frame-container" ondrop="drop(event)" ondragover="allowDrop(event)">
            <p>Drop here (Frame 2)</p>
          </div>

          <div class="condition-container">
            <button ondragstart="drag1(event)" draggable="true">OR</button>
            <button ondragstart="drag1(event)" draggable="true">AND</button>
          </div>
        </div>

        <script>
        var CALLEDFUNCTION = '';

        function allowDrop(event) {
          event.preventDefault();
        }

        function drag(ev) {
          ev.dataTransfer.setData("text", ev.target.innerHTML);
          ev.dataTransfer.setData("source", "tabList");
          ev.dataTransfer.setData("column", ev.target.getAttribute("data-column"));
          CALLEDFUNCTION = 'drag';
        }

        function drag1(ev) {
          ev.dataTransfer.setData("text", ev.target.innerHTML);
          ev.dataTransfer.setData("source", "tabList");
          ev.dataTransfer.setData("column", ev.target.getAttribute("data-column"));
          CALLEDFUNCTION = 'drag1';
        }

        function addDoubleClickEvent(container) {
          container.addEventListener("dblclick", function() {
            var button = container.querySelector("button");
            if (button) {
              var currentMargin = parseInt(button.style.marginLeft) || 0;
              button.style.marginLeft = (currentMargin + 100) + "px";
            }
          });
        }

        function addShiftClickEvent(container) {
          container.addEventListener("click", function(event) {
            if (event.shiftKey) {
              var button = container.querySelector("button");
              if (button) {
                var currentMargin = parseInt(button.style.marginLeft) || 0;
                button.style.marginLeft = (currentMargin - 100) + "px";
              }
            }
          });
        }

        function addClickEvents(container) {
          container.addEventListener("click", function(event) {
            var button = container.querySelector("button");

            // Check if the Ctrl key is pressed (for Windows/Linux) or the Command key for Mac
            var isCtrlKey = event.ctrlKey || event.metaKey;

            if (isCtrlKey) {
              // Remove the button from the container
              if (button) {
                container.removeChild(button);
              }

              // Remove any input, dropdown, or select elements from the container
              var inputs = container.querySelectorAll("input");
              inputs.forEach(function(input) {
                container.removeChild(input);
              });

              var dropdowns = container.querySelectorAll("select");
              dropdowns.forEach(function(dropdown) {
                container.removeChild(dropdown);
              });
            }
          });
        }

        function filterTables() {
          const input = document.getElementById('tableSearch');
          const filter = input.value.toUpperCase();
          const buttons = document.querySelectorAll('.tab-list button');

          buttons.forEach(button => {
            const buttonText = button.innerHTML.toUpperCase();
            if (buttonText.indexOf(filter) > -1) {
              button.style.display = '';
            } else {
              button.style.display = 'none';
            }
          });
        }

        function filterColumns() {
            const input = document.getElementById('columnSearch');
            const filter = input.value.toUpperCase();
            const columns = document.querySelectorAll('.column-list button');
    
            columns.forEach(column => {
              const columnName = column.innerHTML.toUpperCase();
              if (columnName.indexOf(filter) > -1) {
                column.style.display = '';
              } else {
                column.style.display = 'none';
              }
            });
          }

        function drop(ev) {
          ev.preventDefault();
          var data = ev.dataTransfer.getData("text");
          var source = ev.dataTransfer.getData("source");
          var column = ev.dataTransfer.getData("column");

          // Check if the dropped element comes from the table list
          if (source === "tabList") {
            // Create a container div for the dropped elements
            var container = document.createElement("div");
            container.classList.add("dropped-condition");

            // Create a button element
            var button = document.createElement("button");
            button.innerHTML = data;

            if (CALLEDFUNCTION !== 'drag1') {
              // Create a select element (dropdown)
              var select = document.createElement("select");
              select.name = "conditionDropdown";

              var defaultOption = document.createElement("option");
              defaultOption.text = "Select Condition";
              defaultOption.value = "";
              select.appendChild(defaultOption);

              var option1 = document.createElement("option");
              option1.text = "IN";
              option1.value = "IN";
              select.appendChild(option1);

              var option2 = document.createElement("option");
              option2.text = "NOT IN";
              option2.value = "NOT IN";
              select.appendChild(option2);

              var option3 = document.createElement("option");
              option3.text = "START WITH";
              option3.value = "START WITH";
              select.appendChild(option3);

              var option4 = document.createElement("option");
              option4.text = "END WITH";
              option4.value = "END WITH";
              select.appendChild(option4);

              var option5 = document.createElement("option");
              option5.text = "CONTAINS";
              option5.value = "CONTAINS";
              select.appendChild(option5);

              // Append the select element to the button
              button.appendChild(select);

              // Create an input element
              var input = document.createElement("input");
              input.type = "text";
              input.placeholder = "Enter TEXT";

              // Append the input element to the button
              button.appendChild(input);
            }

            // Append the button to the container
            container.appendChild(button);

            // Append the container to the drop target
            ev.target.appendChild(container);

            // Add double-click event to the dropped container
            addDoubleClickEvent(container);

            addShiftClickEvent(container);

            addClickEvents(container);
          }
        }
        </script>
      </body>
      </html>
    `);
  } catch (error) {
    console.error('SQL Error:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/columns/:tableName', async (req, res) => {
  try {
    const { tableName } = req.params;
    const pool = await sql.connect(config);
    const result = await pool
      .request()
      .query(`SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '${tableName}'`);
    const columns = result.recordset;
    res.json(columns);
  } catch (error) {
    console.error('SQL Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.get('/addcolumn/:columnName', (req, res) => {
  try {
    const { columnName } = req.params;
    // Here you can handle what should happen when a column button is clicked
    console.log(`Column Button Clicked: ${columnName}`);
    res.send('Column button clicked!');
  } catch (error) {
    console.error('Error handling column button click:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});
