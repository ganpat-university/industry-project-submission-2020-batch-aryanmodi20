const express = require('express');
const sql = require('mssql');
 
const app = express();
 
const config = {
  server: 'ARYAN-MODI',
  database: 'test',
  user: 'aryan',
  password: 'aryan123',
  options: {
    trustedConnection: true, // Use Windows Authentication
    trustServerCertificate: true
  }
};
 
app.get('/', async (req, res) => {
  try {
    await sql.connect(config);
    const result1 = await sql.query("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'");
    const tableNames = result1.recordset.map(row => row.TABLE_NAME);
   
    res.send(
    `<!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag and Drop Buttons</title>
    <style>
        #container {
            display: flex;
        }
   
        /* Left side container */
        #left-container {
            width: 25%;
            height: 100vh;
            border: 1px solid #ccc;
            padding: 10px;
            overflow-y: auto;
        }
   
        /* Right side container */
        #right-container {
            width: 75%;
            height: 100%;
            border: 1px solid #ccc;
            padding: 10px;
            overflow-y: auto;
        }
   
        .box {
          width: 100%;
          height: 200px;
          border: 1px solid #ddd;
          border-radius: 10px;
          background-color: #fff;
          padding: 10px;
          margin: 10px;
          overflow-y: auto;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
          display: inline-flexbox;
          flex-wrap: wrap;
        }
   
   
        .boxes {
          width: 100%;
          height: 400px; /* Adjust height as needed */
          border: 1px solid #ddd;
          border-radius: 5px;
          background-color: #fff;
          padding: 10px;
          margin: 10px; /* Add margin between boxes */
          overflow-y: auto;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
          flex-direction: column; /* Change to column layout */
        }
   
        .boxes .button{
            display: block;
            margin-bottom: 5px; /* Add margin between buttons */
            width: fit-content; /* Make the button occupy only the necessary width */
        }
 
        .cd{
            width: 100px;
            height:30px;    
            margin:10px;
            padding : 5px,10px;
            border:1px solid#ccc;
            text-align: center;
        }
       
        .drpbutton {
            padding: 5px 10px ;
            background-color: #4ea912;
            cursor: pointer;
            width: 100px;
            height:30px;
            text-align: center;
        }
        .button{
            margin :10px;
        }
    </style>
   
 
    </head>
    <body>
    <div id="container">
   
    <!-- Left side container -->
 
    <div id="left-container">
      <p>Left Side Content</p>
      <input type="text" id="tableSearch" placeholder="Search Table" oninput="filterTables()">
      <div id="tableList">
        ${tableNames.map(name => `<button  data-index="${name}"  class="button">
 
        ${name}
 
      </button>`).join('')}
      </div>
    </div>
   
    <!-- Right side container -->
    <div id="right-container">
      <!-- The right container will be populated dynamically -->
    </div>
  </div>
 
 
  <script>
 
  document.addEventListener('DOMContentLoaded', function () {
      var tableButtons = document.querySelectorAll('#left-container .button');
     
      tableButtons.forEach(function (button) {
        button.addEventListener('click', function () {
          var tableName = button.dataset.index; // Get the table name from the button
 
          fetch('/table/' + tableName)
            .then(response => response.text())
            .then(data => {
              document.getElementById('right-container').innerHTML = data;
            })
            .catch(error => console.error('Error fetching data:', error));
        });
      });
    });
 
    function filterTables() {
      var input, filter, tableList, tableButtons, i;
      input = document.getElementById('tableSearch');
      filter = input.value.toUpperCase();
      tableList = document.getElementById('tableList');
      tableButtons = tableList.getElementsByClassName('button');
      for (i = 0; i < tableButtons.length; i++) {
        if (tableButtons[i].innerText.toUpperCase().indexOf(filter) > -1) {
          tableButtons[i].style.display = '';
        } else {
          tableButtons[i].style.display = 'none';
        }
      }
    }
    function filterColumns() {
      var input, filter, columnList, columnButtons, i;
      input = document.getElementById('columnSearch');
      filter = input.value.toUpperCase();
      columnList = document.getElementById('box1');
      columnButtons = columnList.getElementsByClassName('button');
      for (i = 0; i < columnButtons.length; i++) {
          if (columnButtons[i].innerText.toUpperCase().indexOf(filter) > -1) {
              columnButtons[i].style.display = '';
          } else {
              columnButtons[i].style.display = 'none';
          }
      }
  }
   
        var calledFunction = '';
        function drag(event) {
            event.dataTransfer.setData("text", event.target.dataset.index);
            calledFunction = "drag"  
        }
   
        function drag1(event) {
            event.dataTransfer.setData("text", event.target.dataset.index);
            calledFunction = "drag1"
        }
     
        function allowDrop(event) {
            event.preventDefault();
        }
       
        function drop(event) {
           
            if (calledFunction === "drag"){
            event.preventDefault();
            var data = event.dataTransfer.getData("text");
            var droppedItem = document.createElement("button");
            droppedItem.innerText = "" + data;
            droppedItem.className = "button";
 
           
           
            var dropdownContent = document.createElement("select");
            dropdownContent.innerHTML =\`
                <option value="option1">IN</option>
                <option value="option2">NOT IN</option>
                <option value="option1">=</option>
                <option value="option2"><=</option>
                <option value="option1">=></option>
                <option value="option1">LIKE</option>
                \`;
   
             
            var textBox = document.createElement("input");
            textBox.type = "text";
            textBox.placeholder = "Enter text";
 
            droppedItem.oncontextmenu = function(event)
            {
                event.preventDefault();
                this.remove();  
            }
           
            droppedItem.appendChild(dropdownContent);
            droppedItem.appendChild(textBox);
       
            var mouseY = event.clientY;
            var boxRect = event.target.getBoundingClientRect();
            var children = event.target.getElementsByClassName('button');
         
            if (index === -1) {
                event.target.appendChild(droppedItem);
            } else {
                event.target.insertBefore(droppedItem, children[index]);
            }
       
    }else{
                event.preventDefault();
                var data = event.dataTransfer.getData("text");
                var droppedItem1 = document.createElement("button");
                droppedItem1.innerText = "Condition " + data;
                droppedItem1.className = "button";
                                   
                var dropdownContent = document.createElement("select");
                dropdownContent.innerHTML =\`
                    <option value="option1">OR</option>
                    <option value="option2">AND</option>
                    \`;
                               
                droppedItem1.oncontextmenu = function(event)
                {
                    event.preventDefault();
                    this.remove();  
                }
                droppedItem1.appendChild(dropdownContent);
   
                var mouseY = event.clientY;
                var boxRect = event.target.getBoundingClientRect();
                var children = event.target.getElementsByClassName('button');
         
                var index = Array.from(children).findIndex(button => {
                    var buttonRect = button.getBoundingClientRect();
                    return mouseY < buttonRect.bottom;
                });
         
                if (index === -1) {
                    event.target.appendChild(droppedItem1);
                } else {
                    event.target.insertBefore(droppedItem1, children[index]);
                }
        }
       
     
    }
        </script>
      </body>
      </html>
    `);
  } catch (err) {
    console.error('SQL Error:', err);
    res.status(500).send('Internal Server Error');
  }
});
 
app.get('/table/:tableName', async (req, res) => {
    const { tableName } = req.params;
 
    try {
        await sql.connect(config);
        const result = await sql.query(`SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '${tableName}'`);
        const columnNames = result.recordset.map(row => row.COLUMN_NAME);
 
        res.send(`
        <div id="right-container">
        <!-- Search bar -->
        <input type="text" id="columnSearch" placeholder="Search Columns" oninput="filterColumns()">
        <div id="box1" class="box">
            ${columnNames.map(name => `<button draggable="true" data-index="${name}" ondragstart="drag(event)" class="button">
            ${name}
   
          </button>`).join('')}    </div>
       
            <div id="box2" class="boxes" ondrop="drop(event)" ondragover="allowDrop(event)"></div>
       
            <div id="box3" class="cd" draggable="true" data-index="1" ondragstart="drag1(event)">
                <button class="drpbutton"> OPERATOR</button>
            </div>
        </div>
    </div>
     
        `);
    } catch (err) {
        console.error('SQL Error:', err);
        res.status(500).send('Internal Server Error');
    }
});
 
const PORT = process.env.PORT || 3002;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});