ōvar CALLEDFUNCTION = '';

function allowDrop(event) {
  event.preventDefault();
}

function drag(ev) {
  ev.dataTransfer.setData("text", ev.target.innerHTML);
  ev.dataTransfer.setData("source", ev.target.parentNode.id);
  CALLEDFUNCTION = 'drag';
}

function drag1(ev) {
  ev.dataTransfer.setData("text", ev.target.innerHTML);
  ev.dataTransfer.setData("source", ev.target.parentNode.id);
  CALLEDFUNCTION = 'drag1';
}

function addDoubleClickEvent(container) {
  container.addEventListener("dblclick", function() {
    var button = container.querySelector("button");
    if (button) {
      var currentMargin = parseInt(button.style.marginLeft) || 0;
        button.style.marginLeft = (currentMargin + 100) + "px";
    }
  });
}

function addShiftClickEvent(container) {
  container.addEventListener("click", function(event) {
    if (event.shiftKey) {
      var button = container.querySelector("button");
      if (button) {
        var currentMargin = parseInt(button.style.marginLeft) || 0;
        button.style.marginLeft = (currentMargin - 100) + "px";
      }
    }
  });
}

function addClickEvents(container) {
  container.addEventListener("click", function(event) {
    var button = container.querySelector("button");

    // Check if the Ctrl key is pressed (for Windows/Linux) or the Command key for Mac
    var isCtrlKey = event.ctrlKey || event.metaKey;

    if (isCtrlKey) {
      // Remove the button from the container
      if (button) {
        container.removeChild(button);
      }

      // Remove any input, dropdown, or select elements from the container
      var inputs = container.querySelectorAll("input");
      inputs.forEach(function(input) {
        container.removeChild(input);
      });

      var dropdowns = container.querySelectorAll("select");
      dropdowns.forEach(function(dropdown) {
        container.removeChild(dropdown);
      });
    }
  });
}


function drop(ev) {
  ev.preventDefault();
  var data = ev.dataTransfer.getData("text");
  var source = ev.dataTransfer.getData("source");

  // Create a container div for the dropped elements
  var container = document.createElement("div");
  container.classList.add("dropped-condition");

  // Create a button element
  var button = document.createElement("button");
  button.innerHTML = data;

  if (CALLEDFUNCTION !== 'drag1') {
    // Create a select element (dropdown)
    var select = document.createElement("select");
    select.name = "conditionDropdown";

    var defaultOption = document.createElement("option");
    defaultOption.text = "Select Condition";
    defaultOption.value = "";
    select.appendChild(defaultOption);

    var option1 = document.createElement("option");
    option1.text = "IN";
    option1.value = "IN";
    select.appendChild(option1);

    var option2 = document.createElement("option");
    option2.text = "NOT IN";
    option2.value = "NOT IN";
    select.appendChild(option2);

    var option3 = document.createElement("option");
    option3.text = "START WITH";
    option3.value = "START WITH";
    select.appendChild(option3);

    var option4 = document.createElement("option");
    option4.text = "END WITH";
    option4.value = "END WITH";
    select.appendChild(option4);

    var option5 = document.createElement("option");
    option5.text = "CONTAINS";
    option5.value = "CONTAINS";
    select.appendChild(option5);

    // Append the select element to the button
    button.appendChild(select);

    // Create an input element
    var input = document.createElement("input");
    input.type = "text";
    input.placeholder = "Enter TEXT";

    // Append the input element to the button
    button.appendChild(input);
  }

  // Append the button to the container
  container.appendChild(button);

  // Append the container to the drop target
  ev.target.appendChild(container);

  // Add double-click event to the dropped container
  addDoubleClickEvent(container);

  addShiftClickEvent(container);

  addClickEvents(container);
}
